/**
 *	@file	MOTOR_SPEED.c
 *	@brief	Controla las funciones b�sicas de los motores para avanzar
 *	@par
 *		COPYRIGHT: (C) 2014 Luis Angel Torres, LOS LOMO PLATEADOS.
 *		Todos los derechos reservados.
 */
 
//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "MOTOR_SPEED.h"
#include "PWM.h"
#include "my_types.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	TYPES DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	UNIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
volatile s16 actual_power;

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void update_speed (void);
//------------------------------------------------------------------------------
//	STATE MACHINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
void start_motors_speed (void)
{
	enable_PWMs_speed();
	update_speed();
}

void stop_motor_speed (void)
{
	set_minimum_speed();
	disable_PWMs_speed();
	update_speed();
}

void set_speed (s16 speed)
{
	if ( speed > 0 )
	{
		set_duty_cycle_PWM2(0);
		set_duty_cycle_PWM4(0);
		if ( speed > 100 )
		{
			set_duty_cycle_PWM1(100);
			set_duty_cycle_PWM3(100);
		}
		else
		{
			set_duty_cycle_PWM1(speed);
			set_duty_cycle_PWM3(speed);
		}
	}
	else
	{
		set_duty_cycle_PWM1(0);
		set_duty_cycle_PWM3(0);
		if ( speed < -100 )
		{
			set_duty_cycle_PWM2(100);
			set_duty_cycle_PWM4(100);
		}
		else
		{
			set_duty_cycle_PWM2(-speed);
			set_duty_cycle_PWM4(-speed);
		}
	}
	update_speed();
}

void set_maximum_speed_forward (void)
{
	//Apaga los canales de reversa
	set_duty_cycle_PWM2(0);
	set_duty_cycle_PWM4(0);
	//Pone al 100% los canales de avance
	set_duty_cycle_PWM1(100);
	set_duty_cycle_PWM3(100);
	
	update_speed();
}

void set_minimum_speed (void)
{
	set_duty_cycle_PWM1(0);
	set_duty_cycle_PWM2(0);
	set_duty_cycle_PWM3(0);
	set_duty_cycle_PWM4(0);
	update_speed();
}

void set_maximum_speed_backwards (void)
{
	//Apaga los canales de avance
	set_duty_cycle_PWM1(0);
	set_duty_cycle_PWM3(0);
	//Pone al 100% los canales de reversa
	set_duty_cycle_PWM2(100);
	set_duty_cycle_PWM4(100);
	
	update_speed();
}

void weel_turn_right (u16 turn)
{
	set_duty_cycle_PWM3(turn);
	set_duty_cycle_PWM4(0);
	set_duty_cycle_PWM1(0);
	set_duty_cycle_PWM2(0);
	update_speed();
}

void weel_turn_left (u16 turn)
{
	set_duty_cycle_PWM1(turn);
	set_duty_cycle_PWM2(0);
	set_duty_cycle_PWM3(0);
	set_duty_cycle_PWM4(0);
	update_speed();
}

void increase_speed_in10 (void)
{
	if ( (actual_power + 10) < 100 )
	{
		set_speed(actual_power+10);
	}
	else
	{
		set_maximum_speed_forward();
	}
	update_speed();
}

void decrease_speed_in10 (void)
{
	if ( (actual_power - 10) > -100 )
	{
		set_speed(actual_power-10);
	}
	else
	{
		set_maximum_speed_backwards();
	}
	update_speed();
}

s16 get_actual_speed (void)
{
	return actual_power;
}

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS
//------------------------------------------------------------------------------
void update_speed (void)
{
	if ( get_duty_cycle_PWM1() > 0 )
	{
		actual_power = get_duty_cycle_PWM1();
	}
	else
	{
		actual_power = -get_duty_cycle_PWM2();
	}
}

//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------


