/**
 *	@file	control.c
 *	@brief	Modulo que en base a la evaluaci�n de los datos
 *			de una c�mara, ajusta la velocidad y direcci�n
 *			de los motores de DC y del servo motor.
 *	@par
 *	Created on: Nov 5, 2014
 *		COPYRIGHT: (C) 2014 Luis Angel, LOS LOMO PLATEADOS.
 *		Todos los derechos reservados.
 */

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "my_types.h"
#include "control.h"

//Parece que no es necesario
//#include "camara.h"

#include "MOTOR_DIRECTION.h"

//Cambiar en un futuro por un driver para la velocidad
#include "MOTOR_SPEED.h"

//Probando con este driver la c�mara
#include "tick_timer.h"

#include "dbg_utility.h"


//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define fin_lado_izq					63 //pixeles
#define inicio_lado_der					64 //pixeles
#define fin_lado_der					( 127 - punto_ciego )

#define toltal_puntos_reales			(128-(punto_ciego*2))
#define blind_points					((blind_rate*128)/100)

#define lado_izq_1						((fin_lado_izq) / 10 )
#define lado_izq_2						((2*fin_lado_izq) / 10 )
#define lado_izq_3						((3*fin_lado_izq) / 10 )
#define lado_izq_4						((4*fin_lado_izq) / 10 )
#define lado_izq_5						((5*fin_lado_izq) / 10 )
#define lado_izq_6						((6*fin_lado_izq) / 10 )
#define lado_izq_7						((7*fin_lado_izq) / 10 )
#define lado_izq_8						((8*fin_lado_izq) / 10 )
#define lado_izq_9						((9*fin_lado_izq) / 10 )
#define lado_izq_10						((10*fin_lado_izq) / 10 )

#define lado_der_9					(((1*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_8					(((2*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_7					(((3*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_6					(((4*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_5					(((5*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_4					(((6*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_3					(((7*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_2					(((8*(fin_lado_der-inicio_lado_der))/10)+64)
#define lado_der_1					(((9*(fin_lado_der-inicio_lado_der))/10)+64)


#define m_funcion_turn			((100-first_turn_value)/(9))
#define b_funcion_turn			(first_turn_value-m_funcion_turn)

#define m_funcion_power			((min_turn_power_value-max_turn_power_value)/9)
#define b_funcion_power			( max_turn_power_value + m_funcion_power )


#define giro1_dir_value					((m_funcion_turn*1)+b_funcion_turn)
#define giro2_dir_value					((m_funcion_turn*2)+b_funcion_turn)
#define giro3_dir_value					((m_funcion_turn*3)+b_funcion_turn)
#define giro4_dir_value					((m_funcion_turn*4)+b_funcion_turn)
#define giro5_dir_value					((m_funcion_turn*5)+b_funcion_turn)
#define giro6_dir_value					((m_funcion_turn*6)+b_funcion_turn)
#define giro7_dir_value					((m_funcion_turn*7)+b_funcion_turn)
#define giro8_dir_value					((m_funcion_turn*8)+b_funcion_turn)
#define giro9_dir_value					((m_funcion_turn*9)+b_funcion_turn)
#define giro10_dir_value				((m_funcion_turn*10)+b_funcion_turn)

#define giro1_pwr_value					((m_funcion_power*1)+b_funcion_power)
#define giro2_pwr_value					((m_funcion_power*2)+b_funcion_power)
#define giro3_pwr_value					((m_funcion_power*3)+b_funcion_power)
#define giro4_pwr_value					((m_funcion_power*4)+b_funcion_power)
#define giro5_pwr_value					((m_funcion_power*5)+b_funcion_power)
#define giro6_pwr_value					((m_funcion_power*6)+b_funcion_power)
#define giro7_pwr_value					((m_funcion_power*7)+b_funcion_power)
#define giro8_pwr_value					((m_funcion_power*8)+b_funcion_power)
#define giro9_pwr_value					((m_funcion_power*9)+b_funcion_power)
#define giro10_pwr_value				((m_funcion_power*10)+b_funcion_power)

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	TYPES DEFINITIONS
//------------------------------------------------------------------------------
typedef struct
{
		u16 actual_state;
		u16 next_state;
}tsSM;

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------
enum
{
	IDLE_STATE,

	CAMARA_STATE,
	BLIND_STATE,

	LINE_CONFIR_STATE,
	LINE_STATE,

	RIGHT_LEVEL_STATE,
	ANALYSIS_RIGHT_STATE,
	RIGHT_TURN_STATE,

	LEFT_LEVEL_STATE,
	ANALYSIS_LEFT_STATE,
	LEFT_TURN_STATE,
};

enum
{
	GIRO_GRADO0 = 0,
	GIRO_GRADO1,
	GIRO_GRADO2,
	GIRO_GRADO3,
	GIRO_GRADO4,
	GIRO_GRADO5,
	GIRO_GRADO6,
	GIRO_GRADO7,
	GIRO_GRADO8,
	GIRO_GRADO9,
	GIRO_GRADO10
};

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	UNIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
//static u16 line_counter;
volatile u16 line_counter;
static u08 turn_grade;
static u08 previous_turn_grade;
static u16 wait_turn;
static u16 lost_time_wait;
static u16 counter_blind1;
static u16 counter_blind2;

tsSM controlMaquina1;

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void control_idle_state (void);

void control_camara_state (void);
void control_blind_state (void);

void control_line_confir_state (void);
void control_line_state (void);

void control_right_level_state(void);
void control_analysis_right_level_state(void);
void control_right_turn_state (void);

void control_left_level_state(void);
void control_analysis_left_level_state(void);
void control_left_turn_state (void);


//------------------------------------------------------------------------------
//	STATE MACHINES
//------------------------------------------------------------------------------
void (* const control_execute_state [] ) (void) = 
{
		control_idle_state,

		control_camara_state,
		control_blind_state,

		control_line_confir_state,
		control_line_state,

		control_right_level_state,
		control_analysis_right_level_state,
		control_right_turn_state,

		control_left_level_state,
		control_analysis_left_level_state,
		control_left_turn_state
};

/*****************************************
 * FUNCIONES DE LA MAQUINA DE ESTADOS
 ****************************************/

void control_idle_state (void)
{
	controlMaquina1.actual_state = IDLE_STATE;
	controlMaquina1.next_state = IDLE_STATE;
}

void control_camara_state (void)
{
	u16 giro_der = 0;
	u16 giro_izq = 0;
	u08 counter;

	//Recorre el lado izq del frame
	//para checar si no hay objetos
	counter = fin_lado_izq;
	do{
		if ( actual_frame[counter] )
		{
			giro_der += 1;
		}
	}while( (counter-- > punto_ciego) );

	//Recorre el lado der del frame
	//para checar si no hay objetos
	counter = fin_lado_der;
	do{
		if ( actual_frame[counter] )
		{
			giro_izq += 1;
		}
	}while( (counter-- > inicio_lado_der) );

	//Cambia el estaco actual
	controlMaquina1.actual_state = CAMARA_STATE;

	//Pregunta si el giro izq y el giro der fueron activados
	//if ( ( (!giro_izq) & BIT1 ) & ( (!giro_der) & BIT1 ) )
	if ( (giro_izq == 0) & (giro_der == 0) )
	{
		controlMaquina1.next_state = LINE_CONFIR_STATE;
	}
	else if ( (giro_izq + giro_der) > blind_points )
	{
		controlMaquina1.next_state = BLIND_STATE;
	}
	else if ( giro_izq > giro_der )
	{
		controlMaquina1.next_state = LEFT_LEVEL_STATE;
	}
	else
	{
		controlMaquina1.next_state = RIGHT_LEVEL_STATE;
	}	
}

void control_blind_state (void)
{
	//Ajusta la direcci�n frontal
	//y el poder cuando est� ciego
	set_front_direction();
	set_front_direction();
	set_speed(blind_power);

	//Ajusta el estado actual
	//y el estado siguiente
	controlMaquina1.actual_state = BLIND_STATE;
	controlMaquina1.next_state = CAMARA_STATE;
}

void control_line_confir_state (void)
{	
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado Confirm Recta\r\n") );

	//Varables necesarias para
	//operaciones mas adelante
	u08 confirm_linea = 0;
	u08 counter = fin_lado_der;

	//Verifica que no haya puntos
	//para elegir el siguiente estado
	do{
		if ( actual_frame[counter] )
		{
			confirm_linea = 1;
		}
	}while( (counter-- > punto_ciego) );

	//En base al estado anterior,
	//se toman diferentes deciciones
	switch (controlMaquina1.actual_state)
	{
		case CAMARA_STATE:
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: FROM CAMARA_STATE\r\n") );

			//Ajusta la direcci�n y 
			//y el poder de los motores
			set_front_direction();
			set_speed(line_confirm_power);

			line_counter = 0;

			//Si encontr� puntos vuelve a CAMARA_STATE
			//sino, se va a si mismo
			if ( confirm_linea )
			{
				controlMaquina1.next_state = CAMARA_STATE;
			}
			else
			{
				controlMaquina1.next_state = LINE_CONFIR_STATE;
			}

			break;
		case LINE_CONFIR_STATE:
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: FROM LINE_CONFIR_STATE\r\n") );

			//Ajusta la direcci�n y 
			//y el poder de los motores
			set_front_direction();
			set_speed(line_confirm_power);

			//Si encontr� puntos vuelve a CAMARA_STATE
			//sino, se va a si mismo
			if ( confirm_linea )
			{
				controlMaquina1.next_state = CAMARA_STATE;
			}
			else if ( line_counter > confirm_line_time )
			{
				controlMaquina1.next_state = LINE_STATE;
			}
			else
			{
				controlMaquina1.next_state = LINE_CONFIR_STATE;
				line_counter++;
			}

			break;
		case LINE_STATE:
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: FROM LINE_STATE\r\n") );
			//Si encontr� puntos vuelve a CAMARA_STATE
			//sino, se va al estado LINE
			if ( confirm_linea )
			{
				controlMaquina1.next_state = CAMARA_STATE;
			}
			else
			{
				controlMaquina1.next_state = LINE_STATE;
			}

			break;
		default:
			controlMaquina1.next_state = IDLE_STATE;
			break;
	}
	//Actialuza el estado actual
	controlMaquina1.actual_state = LINE_CONFIR_STATE;
}

void control_line_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado Linea Recta\r\n") );
	//Ajusta la direcci�n y 
	//y el poder de los motores
	set_front_direction();
	set_speed(max_limit_power);
	//set_minimum_speed();

	//Ajusta el estado actual
	//y el estado siguiente
	controlMaquina1.actual_state = LINE_STATE;
	controlMaquina1.next_state = LINE_CONFIR_STATE;
}

void control_right_level_state (void)
{
	//Varables necesarias para
	//operaciones mas adelante.
	u08 counter = 0;
	counter_blind1 = GIRO_GRADO0;
	counter_blind2 = GIRO_GRADO0;
	turn_grade = GIRO_GRADO0;

	//Dependiendo de d�nde encuentre puntos,
	//asigna un grado de giro para el
	//siguiente estado. Entre mas cerca del
	//centro, mas grande es el grado.
	counter = punto_ciego;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO1;
			counter_blind1 = GIRO_GRADO1;
		}
	}while( ++counter < lado_izq_1 );
	counter = lado_izq_1;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO2;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_2 );
	counter = lado_izq_2;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO3;
		}
	}while( ++counter < lado_izq_3 );
	counter = lado_izq_3;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO4;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_4 );
	counter = lado_izq_4;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO5;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_5 );
	counter = lado_izq_5;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO6;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_6 );
	counter = lado_izq_6;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO7;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_7 );
	counter = lado_izq_7;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO8;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_8 );
	counter = lado_izq_8;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO9;
			//counter_blind++;
		}
	}while( ++counter < lado_izq_9 );
	counter = lado_izq_9;
	do{
		if ( actual_frame[counter] )
		{
			turn_grade = GIRO_GRADO10;
			counter_blind2 = GIRO_GRADO10;
		}
	}while( counter++ < lado_izq_10 );

	//Actialuza el estado actual y siguiente
	controlMaquina1.actual_state = RIGHT_LEVEL_STATE;
	controlMaquina1.next_state = ANALYSIS_RIGHT_STATE;

}

void control_analysis_right_level_state (void)
{
	//Actialuza el estado actual
	controlMaquina1.actual_state = RIGHT_LEVEL_STATE;

	if ( turn_grade  )
	{
		if ( (counter_blind1 > GIRO_GRADO0)  && (counter_blind2 > GIRO_GRADO2) )
		{
			lost_time_wait = lost_wait_time;
			controlMaquina1.next_state = CAMARA_STATE;
		}
		else
		{
			lost_time_wait = lost_wait_time;
			previous_turn_grade = turn_grade;
			controlMaquina1.next_state = RIGHT_TURN_STATE;
		}
	}
	else
	{
		if ( (previous_turn_grade < GIRO_GRADO4) || ( lost_time_wait == 0 ) )
			//if ( ((previous_turn_grade < GIRO_GRADO4) || ( lost_time_wait == 0 )) || (counter_blind > 50) )
		{
			lost_time_wait = lost_wait_time;
			controlMaquina1.next_state = CAMARA_STATE;
		}
		else
		{
			turn_grade = previous_turn_grade;
			lost_time_wait--;
			controlMaquina1.next_state = RIGHT_TURN_STATE;
		}
	}

}

#if tipo_giro == giro_normal
void control_right_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO DER\r\n") );
	controlMaquina1.actual_state = RIGHT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(giro5_dir_value);
				set_speed(giro5_pwr_value);
				break;
			case GIRO_GRADO6:
				set_direction(giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_right(giro6_pwr_value);
				break;
			case GIRO_GRADO7:
				set_direction(giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_right(giro7_pwr_value);
				break;
			case GIRO_GRADO8:
				set_direction(giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_right(giro8_pwr_value);
				break;
			case GIRO_GRADO9:
				set_direction(giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_right(giro9_pwr_value);
				break;
			case GIRO_GRADO10:
				set_direction(giro10_dir_value);
				//set_speed(giro10_pwr_value);
				weel_turn_right(giro10_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_LEVEL_STATE;
	}
}
#elif tipo_giro == llanta_70
void control_right_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO DER\r\n") );
	controlMaquina1.actual_state = RIGHT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(giro5_dir_value);
				set_speed(giro5_pwr_value);
				break;
			case GIRO_GRADO6:
				set_direction(giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_right(giro6_pwr_value);
				break;
			case GIRO_GRADO7:
				set_direction(giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_right(giro7_pwr_value);
				break;
			case GIRO_GRADO8:
				set_direction(giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_right(giro7_pwr_value);
				break;
			case GIRO_GRADO9:
				set_direction(giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_right(giro7_pwr_value);
				break;
			case GIRO_GRADO10:
				set_direction(giro10_dir_value);
				//set_speed(giro10_pwr_value);
				weel_turn_right(giro7_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_LEVEL_STATE;
	}
}
#elif tipo_giro == llanta_50
void control_right_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO DER\r\n") );
	controlMaquina1.actual_state = RIGHT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(giro5_dir_value);
				//set_speed(giro5_pwr_value);
				weel_turn_right(giro5_pwr_value);
				break;
			case GIRO_GRADO6:
				set_direction(giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_right(giro5_pwr_value);
				break;
			case GIRO_GRADO7:
				set_direction(giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_right(giro5_pwr_value);
				break;
			case GIRO_GRADO8:
				set_direction(giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_right(giro5_pwr_value);
				break;
			case GIRO_GRADO9:
				set_direction(giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_right(giro5_pwr_value);
				break;
			case GIRO_GRADO10:
				set_direction(giro10_dir_value);
				//set_speed(giro10_pwr_value);
				weel_turn_right(giro5_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_LEVEL_STATE;
	}
}
#elif tipo_giro == giro_poder_normal
void control_right_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO DER\r\n") );
	controlMaquina1.actual_state = RIGHT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(giro5_dir_value);
				//set_speed(giro5_pwr_value);
				weel_turn_right(max_turn_power_value);
				break;
			case GIRO_GRADO6:
				set_direction(giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_right(max_turn_power_value);
				break;
			case GIRO_GRADO7:
				set_direction(giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_right(max_turn_power_value);
				break;
			case GIRO_GRADO8:
				set_direction(giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_right(max_turn_power_value);
				break;
			case GIRO_GRADO9:
				set_direction(giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_right(max_turn_power_value);
				break;
			case GIRO_GRADO10:
				set_direction(giro10_dir_value);
				//set_speed(giro10_pwr_value);
				weel_turn_right(max_turn_power_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = RIGHT_LEVEL_STATE;
	}
}
#endif

void control_left_level_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado CONFIRM GIRO IZQ\r\n") );
	//Varables necesarias para
	//operaciones mas adelante.
	u08 counter = 0;
	counter_blind1 = GIRO_GRADO0;
	counter_blind2 = GIRO_GRADO0;
	turn_grade = GIRO_GRADO0;

	//Dependiendo de d�nde encuentre puntos,
	//asigna un grado de giro para el
	//siguiente estado. Entre mas cerca del
	//centro, mas grande es el grado.
	counter = fin_lado_der;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO1 IZQ\r\n") );
			turn_grade = GIRO_GRADO1;
			counter_blind1 = GIRO_GRADO1;
		}
	}while( --counter < lado_der_1 );
	counter = lado_der_1;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO2 IZQ\r\n") );
			turn_grade = GIRO_GRADO2;
			//counter_blind++;
		}
	}while( --counter < lado_der_2 );
	counter = lado_der_2;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO3 IZQ\r\n") );
			turn_grade = GIRO_GRADO3;
			//counter_blind++;
		}
	}while( --counter < lado_der_3 );
	counter = lado_der_3;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO4 IZQ\r\n") );
			turn_grade = GIRO_GRADO4;
			//counter_blind++;
		}
	}while( --counter < lado_der_4 );
	counter = lado_der_4;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO5 IZQ\r\n") );
			turn_grade = GIRO_GRADO5;
			//counter_blind++;
		}
	}while( --counter < lado_der_5 );
	counter = lado_der_5;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO6 IZQ\r\n") );
			turn_grade = GIRO_GRADO6;
			//counter_blind++;
		}
	}while( --counter < lado_der_6 );
	counter = lado_der_6;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO7 IZQ\r\n") );
			turn_grade = GIRO_GRADO7;
			//counter_blind++;
		}
	}while( --counter < lado_der_7 );
	counter = lado_der_7;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO8 IZQ\r\n") );
			turn_grade = GIRO_GRADO8;
			//counter_blind++;
		}
	}while( --counter < lado_der_8 );
	counter = lado_der_8;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO9 IZQ\r\n") );
			turn_grade = GIRO_GRADO9;
			//counter_blind++;
		}
	}while( --counter < lado_der_9 );
	counter = lado_der_9;
	do{
		if ( actual_frame[counter] )
		{
			//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: GIRO10 IZQ\r\n") );
			turn_grade = GIRO_GRADO10;
			counter_blind2 = GIRO_GRADO10;
			//counter_blind++;
		}
	}while( counter-- < inicio_lado_der );

	//Actialuza el estado actual y siguiente
	controlMaquina1.actual_state = LEFT_LEVEL_STATE;
	controlMaquina1.next_state = ANALYSIS_LEFT_STATE;
}


void control_analysis_left_level_state (void)
{
	//Actialuza el estado actual
	controlMaquina1.actual_state = LEFT_LEVEL_STATE;

	if ( turn_grade  )
	{
		if ( (counter_blind1 > GIRO_GRADO0)  && (counter_blind2 > GIRO_GRADO2) )
		{
			lost_time_wait = lost_wait_time;
			controlMaquina1.next_state = CAMARA_STATE;
		}
		else
		{
			lost_time_wait = lost_wait_time;
			previous_turn_grade = turn_grade;
			controlMaquina1.next_state = LEFT_TURN_STATE;
		}
	}
	else
	{
		if ( (previous_turn_grade < GIRO_GRADO4) || ( lost_time_wait == 0 ) )
			//if ( ((previous_turn_grade < GIRO_GRADO4) || ( lost_time_wait == 0 )) || (counter_blind > 50) )
		{
			lost_time_wait = lost_wait_time;
			controlMaquina1.next_state = CAMARA_STATE;
		}
		else
		{
			turn_grade = previous_turn_grade;
			lost_time_wait--;
			controlMaquina1.next_state = LEFT_TURN_STATE;
		}
	}
}

#if tipo_giro == giro_normal
void control_left_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO IZQ\r\n") );

	controlMaquina1.actual_state = LEFT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(-giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(-giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(-giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(-giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(-giro5_dir_value);
				set_speed(giro5_pwr_value);
				//weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO6:
				set_direction(-giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_left(giro6_pwr_value);
				break;
			case GIRO_GRADO7:
				set_direction(-giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_left(giro7_pwr_value);
				break;
			case GIRO_GRADO8:
				set_direction(-giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_left(giro8_pwr_value);
				break;
			case GIRO_GRADO9:
				set_direction(-giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_left(giro9_pwr_value);
				break;
			case GIRO_GRADO10:
				set_direction(-giro10_dir_value);
				weel_turn_left(giro10_pwr_value);
				//set_speed(giro10_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_LEVEL_STATE;
	}
}
#elif tipo_giro == llanta_70
void control_left_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO IZQ\r\n") );

	controlMaquina1.actual_state = LEFT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(-giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(-giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(-giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(-giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(-giro5_dir_value);
				set_speed(giro5_pwr_value);
				//weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO6:
				set_direction(-giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_left(giro6_pwr_value);
				break;
			case GIRO_GRADO7:
				set_direction(-giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_left(giro7_pwr_value);
				break;
			case GIRO_GRADO8:
				set_direction(-giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_left(giro7_pwr_value);
				break;
			case GIRO_GRADO9:
				set_direction(-giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_left(giro7_pwr_value);
				break;
			case GIRO_GRADO10:
				set_direction(-giro10_dir_value);
				weel_turn_left(giro7_pwr_value);
				//set_speed(giro10_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_LEVEL_STATE;
	}
}
#elif tipo_giro == llanta_50
void control_left_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO IZQ\r\n") );

	controlMaquina1.actual_state = LEFT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(-giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(-giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(-giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(-giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(-giro5_dir_value);
				//set_speed(giro5_pwr_value);
				weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO6:
				set_direction(-giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO7:
				set_direction(-giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO8:
				set_direction(-giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO9:
				set_direction(-giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_left(giro5_pwr_value);
				break;
			case GIRO_GRADO10:
				set_direction(-giro10_dir_value);
				weel_turn_left(giro5_pwr_value);
				//set_speed(giro10_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_LEVEL_STATE;
	}
}
#elif tipo_giro == giro_poder_normal
void control_left_turn_state (void)
{
	//DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Estado GIRO IZQ\r\n") );

	controlMaquina1.actual_state = LEFT_TURN_STATE;

	if (wait_turn < wait_turn_time)
	{
		switch (turn_grade)
		{
			case GIRO_GRADO1:
				set_direction(-giro1_dir_value);
				set_speed(giro1_pwr_value);
				break;
			case GIRO_GRADO2:
				set_direction(-giro2_dir_value);
				set_speed(giro2_pwr_value);
				break;
			case GIRO_GRADO3:
				set_direction(-giro3_dir_value);
				set_speed(giro3_pwr_value);
				break;
			case GIRO_GRADO4:
				set_direction(-giro4_dir_value);
				set_speed(giro4_pwr_value);
				break;
			case GIRO_GRADO5:
				set_direction(-giro5_dir_value);
				//set_speed(giro5_pwr_value);
				weel_turn_left(max_turn_power_value);
				break;
			case GIRO_GRADO6:
				set_direction(-giro6_dir_value);
				//set_speed(giro6_pwr_value);
				weel_turn_left(max_turn_power_value);
				break;
			case GIRO_GRADO7:
				set_direction(-giro7_dir_value);
				//set_speed(giro7_pwr_value);
				weel_turn_left(max_turn_power_value);
				break;
			case GIRO_GRADO8:
				set_direction(-giro8_dir_value);
				//set_speed(giro8_pwr_value);
				weel_turn_left(max_turn_power_value);
				break;
			case GIRO_GRADO9:
				set_direction(-giro9_dir_value);
				//set_speed(giro9_pwr_value);
				weel_turn_left(max_turn_power_value);
				break;
			case GIRO_GRADO10:
				set_direction(-giro10_dir_value);
				weel_turn_left(max_turn_power_value);
				//set_speed(giro10_pwr_value);
				break;
			default:
				set_direction(0);
				set_speed(60);
				break;
		}

		//Incrementa el contador del tiempo
		wait_turn++;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_TURN_STATE;

	}
	else
	{
		//resetea el contador del tiempo
		wait_turn = 0;

		//Actialuza el estado siguiente
		controlMaquina1.next_state = LEFT_LEVEL_STATE;
	}
}
#endif


//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
void control_execute_next_state (void)
{
	control_execute_state[controlMaquina1.next_state]();
}

void start_control_machine (void)
{
	line_counter = 0;
	turn_grade = GIRO_GRADO0;
	previous_turn_grade = GIRO_GRADO0;
	wait_turn = 0;
	counter_blind1 = GIRO_GRADO0;
	counter_blind2 = GIRO_GRADO0;
	lost_time_wait = lost_wait_time;
	controlMaquina1.next_state = CAMARA_STATE;
}


//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS
//------------------------------------------------------------------------------
//Ejecuci�n de los estados siguientes de la maquina de estados


//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------

