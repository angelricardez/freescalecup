/**
 *	@file	leds.c
 *	@brief	Driver de led
 *	@par
 *		COPYRIGHT: (C) 2014 CDE, ITESM.
 *		Todos los derechos reservados.
 */
 
//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "leds.h"
#include "my_types.h"
#include "events_engine.h"
#include "events_ids.h"
/*#include "dbg_utility.h"
#include "board_defs.h"*/
#include "board_defs.h"
//#include "derivative.h" /* include peripheral declarations */


//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	TYPES DEFINITIONS
//------------------------------------------------------------------------------
typedef struct
{
	u08 actual_state;
	u08 next_state;
}ledSM;

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------
enum
{
	idle_state,
	led_on,
	led_off,
	times_counter,
};

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	UNIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
static u08 led_frec;
static u08 led_counter_frec;
static u08 led_times;

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void vfn_led_wait (void);
void vfn_idle_sm (void);
void vfn_led_on_sm (void);
void vfn_led_off_sm (void);
void vfn_times_counter_sm (void);

//------------------------------------------------------------------------------
//	STATE MACHINES
//------------------------------------------------------------------------------
ledSM led_state_machine;

void (* vfn_execute_state [] ) (void) =
{
		vfn_idle_sm,
		vfn_led_on_sm,
		vfn_led_off_sm,
		vfn_times_counter_sm,
};

void vfn_idle_sm (void)
{
	vfn_periodic_timer_disable(LED_PEV);
}

void vfn_led_on_sm (void)
{
	LEDSB_CLR = BIT18;
	vfn_led_wait();
}

void vfn_led_off_sm (void)
{
	LEDSB_SET = BIT18;
	vfn_led_wait();
}

void vfn_times_counter_sm (void)
{
	if(led_times > 1)
	{
		led_times --;
		led_state_machine.next_state = led_on;
	}else{
		led_state_machine.next_state = idle_state;
	}
}

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
void vfn_execute_next_state_sm (void)
{
	led_state_machine.actual_state = led_state_machine.next_state;
	vfn_execute_state[led_state_machine.next_state]();

}

void vfn_leds_sm_luncher (u08 frec, u08 times)
{
	led_frec = frec;
	led_times = times;
	led_counter_frec = frec;
	led_state_machine.actual_state = idle_state;
	led_state_machine.next_state = led_on;
	vfn_periodic_timer_enable(LED_PEV);
}

void vfn_led_periodic_cb (void)
{
	LEDSB_TOG = BIT19;
}

void vfn_led_init(void)
{
	//Habilita el modulo PORTB
	SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK;
	
	PUERTO_B18 |= BIT8 | BIT2 | BIT0;
	PUERTO_B19 |= BIT8 | BIT2 | BIT0;
	
	LEDSB_DIR |= BIT18 | BIT19;
	LEDSB_OUT |= BIT18;
}

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS
//------------------------------------------------------------------------------
void vfn_led_wait (void)
{
	if( led_counter_frec > 1)
	{
		led_counter_frec --;
	}else{
		led_counter_frec = led_frec;
		if(led_state_machine.actual_state == led_on)
		{
			led_state_machine.next_state = led_off;
		}else{
			led_state_machine.next_state = times_counter;
		}
	}
}


//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
