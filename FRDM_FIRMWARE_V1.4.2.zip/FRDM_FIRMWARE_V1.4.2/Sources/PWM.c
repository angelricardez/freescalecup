/**
 *	@file	PWM.c
 *	@brief	Funciones para inicializar y controlar el PWM
 *	@par
 *		COPYRIGHT: (C) 2014 Luis Angel, LOS LOMO PLATEADOS.
 *		Todos los derechos reservados.
 */
 
//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "PWM.h"
#include "derivative.h" /* include peripheral declarations */
#include "board_defs.h"
#include "my_types.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void init_TPM_general (void);
void init_TPM0_PWMs (void);
void init_TPM1_PWMs (void);

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
void init_PWM(void)
{
	init_TPM_general ();
	init_TPM0_PWMs ();
	init_TPM1_PWMs ();
}

void enable_PWMs_speed (void)
{
	TPM0_SC |= TPM_SC_CMOD(1);
}

void enable_PWMs_direction (void)
{
	TPM1_SC |= TPM_SC_CMOD(1);
}

void disable_PWMs_speed (void)
{
	TPM0_SC &= ~(TPM_SC_CMOD(1));
}

void disable_PWMs_direction (void)
{
	TPM1_SC &= ~(TPM_SC_CMOD(1));
}


//Asigna valor a los duty cycle de los PWMs

void set_duty_cycle_PWM1 (u16 porcentaje)
{
	TPM0_C2V = ((TPM0_counter_value*porcentaje)/100);
}

void set_duty_cycle_PWM2 (u16 porcentaje)
{
	TPM0_C3V = ((TPM0_counter_value*porcentaje)/100);
}

void set_duty_cycle_PWM3 (u16 porcentaje)
{
	TPM0_C0V = ((TPM0_counter_value*porcentaje)/100);
}

void set_duty_cycle_PWM4 (u16 porcentaje)
{
	TPM0_C1V = ((TPM0_counter_value*porcentaje)/100);
}

void set_duty_cycle_PWM5 (u16 porcentaje)
{
	TPM1_C0V = ((TPM1_counter_value*porcentaje)/100);
}

void set_duty_cycle_PWM1_direction (u16 milesimas)
{
	TPM1_C0V = (TPM1_counter_value*milesimas)/10000;
}

//Obtiene los porcentajes de los duty cycle

u16 get_duty_cycle_PWM1 (void)
{
	return ( (TPM0_C2V*100)/(TPM0_counter_value) );
}

u16 get_duty_cycle_PWM2 (void)
{
	return ( (TPM0_C3V*100)/(TPM0_counter_value) );
}

u16 get_duty_cycle_PWM3 (void)
{
	return ( (TPM0_C0V*100)/(TPM0_counter_value) );
}

u16 get_duty_cycle_PWM4 (void)
{
	return ( (TPM0_C1V*100)/(TPM0_counter_value) );
}

u16 get_duty_cycle_PWM1_direction (void)
{
	return ( (TPM1_C0V*10000)/(TPM1_counter_value) );
}

u16 get_duty_cycle_PWM2_direction (void)
{
	return ( (TPM1_C1V*100)/(TPM1_counter_value) );
}


//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS
//------------------------------------------------------------------------------
void init_TPM_general(void)
{
	//Elije Reloj de 48MHZ para modulos TPM
	/* Provide clock for the TPM module (Section 5.7.5 TPM clocking from "KL25 Sub-Family Reference Manual") */
	/* Select MCGPLLCLK/2 as clock source in SIM_SOPT2 (Section 12.2.3 System Options Register 2 (SIM_SOPT2)  from "KL25 Sub-Family Reference Manual") */
	SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK;
	/* Clear previous configuration of clock selected for TPM (Section 12.2.3 System Options Register 2 (SIM_SOPT2)  from "KL25 Sub-Family Reference Manual") */
	SIM_SOPT2 &= ~(SIM_SOPT2_TPMSRC_MASK);
	/* Select finally the source for TPM. Clock source provided by MCGPLLCLK/2  (Section 12.2.3 System Options Register 2 (SIM_SOPT2) from "KL25 Sub-Family Reference Manual") */
	/* 01 MCGFLLCLK clock or MCGPLLCLK/2 */
	SIM_SOPT2 |= SIM_SOPT2_TPMSRC(1);
}

void init_TPM0_PWMs (void)
{
	//Habilita el reloj para el modulo TPM0
	SIM_SCGC6 |= SIM_SCGC6_TPM0_MASK;
	
	/********************************************
	 ********** Configura Modulo TPM 0 **********
	 ********************************************/
	
	//Blow away the control registers to ensure that the counter is not running
	// Disable TPM1 to configure
	TPM0_SC = 0;
	TPM0_CONF = 0;
	
	//While the counter is disabled we can setup the prescaler, con 128
	TPM0_SC |= TPM_SC_PS(7);
	//TPM1_SC |= TPM_SC_TOIE_MASK; //Enable Interrupts for the Timer Overflow
	
	//Setup the mod register to get the correct PWM Period, el periodo queda en 20ms
	TPM0_MOD = TPM0_counter_value;
	
	/*********************************************************************/
	//Setup Channel 0
	/* Edge-aligned PWM; clear Output on match, set Output on reload */
	TPM0_C0SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
	
	//Set the Default duty cycle
	TPM0_C0V = TPM0_duty_counter_init;
	/**********************************************************************/
	//Setup Channel 1
	/* Edge-aligned PWM; clear Output on match, set Output on reload */
	TPM0_C1SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
		
	//Set the Default duty cycle
	TPM0_C1V = TPM0_duty_counter_init;
	/*********************************************************************/
	//Setup Channel 2
	/* Edge-aligned PWM; clear Output on match, set Output on reload */
	TPM0_C2SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
		
	//Set the Default duty cycle
	TPM0_C2V = TPM0_duty_counter_init;
	/*********************************************************************/
	//Setup Channel 3
	/* Edge-aligned PWM; clear Output on match, set Output on reload */
	TPM0_C3SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
		
	//Set the Default duty cycle
	TPM0_C3V = TPM0_duty_counter_init;
	/*********************************************************************/
	
	//Enable the FTM functions on the the port
	/* Turn on clock to PortC module */
	SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
	PORTC_PCR1 |= PORT_PCR_MUX(4);
	PORTC_PCR2 |= PORT_PCR_MUX(4);
	
	PORTC_PCR3 |= PORT_PCR_MUX(4);
	PORTC_PCR4 |= PORT_PCR_MUX(4);
	//PORTB_PCR1 = PORT_PCR_MUX(3);
}

void init_TPM1_PWMs (void)
{
	//Habilita el reloj para el modulo TPM1
	SIM_SCGC6 |= SIM_SCGC6_TPM1_MASK;
	
	/********************************************
	 ********** Configura Modulo TPM 1 **********
	 ********************************************/
	
	//Blow away the control registers to ensure that the counter is not running
	// Disable TPM1 to configure
	TPM1_SC = 0;
	TPM1_CONF = 0;
	
	//While the counter is disabled we can setup the prescaler, con 128
	TPM1_SC |= TPM_SC_PS(7);
	//TPM1_SC |= TPM_SC_TOIE_MASK; //Enable Interrupts for the Timer Overflow
	
	//Setup the mod register to get the correct PWM Period, el periodo queda en 20ms
	TPM1_MOD = TPM1_counter_value;
	
	/*********************************************************************/
	//Setup Channel 0
	/* Edge-aligned PWM; clear Output on match, set Output on reload */
	TPM1_C0SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
	//TPM1_C1SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
	
	//Set the Default duty cycle
	TPM1_C0V = TPM1_duty_counter_init;
	/*
	//Setup Channel 1
	// Edge-aligned PWM; clear Output on match, set Output on reload 
	TPM1_C1SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
	//TPM1_C1SC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
		
	//Set the Default duty cycle
	TPM1_C1V = TPM1_duty_counter_init;										*/
	/**************************************************************/
	
	//Enable the TPM COunter
	//TPM1_SC |= TPM_SC_CMOD(1);
	
	//Enable the FTM functions on the the port
	/* Turn on clock to PortB module */
	SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK;
	PORTB_PCR0 |= PORT_PCR_MUX(3);
	//PORTB_PCR1 |= PORT_PCR_MUX(3);
	//PORTB_PCR1 = PORT_PCR_MUX(3);
}


//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------



