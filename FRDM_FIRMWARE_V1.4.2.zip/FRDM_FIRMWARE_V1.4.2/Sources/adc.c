/*
 * adc.c
 *
 *  Created on: Oct 23, 2014
 *      Author: LuisAngel
 */

#include "ADC.h"
#include "my_types.h"
//**************************************************
//					ADC DRIVERS
//**************************************************

void ADC_Init16b_hardware(void)
{
	//Habilita el clock para el ADC0
	SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
	
	//Triggers alternativos habilitados, pre-trigger para canal B, 
	//Modulo PIT0 para trigger
	SIM_SOPT7 |= SIM_SOPT7_ADC0ALTTRGEN_MASK | SIM_SOPT7_ADC0PRETRGSEL_MASK
				| SIM_SOPT7_ADC0TRGSEL(trigger);
	
	ADC0_CFG1 |= (ADC_CFG1_MODE(3) | 
			      ADC_CFG1_ADIV(2));
	
	ADC0_SC1B  |= ADC_SC1_ADCH(31); //Disable module
	
	//Hardware trigger
	ADC0_SC2 |= ADC_SC2_ADTRG_MASK;
	
	ADC0_CFG2 |= ADC_CFG2_MUXSEL_MASK; //Escucha los canales b
}

void ADC_Init16b_software(void)
{
	SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
	
	ADC0_CFG1 |= (ADC_CFG1_MODE(3) | 
			      ADC_CFG1_ADIV(2));
	
	ADC0_SC1A  = ADC_SC1_ADCH(31); //Disable module
}

void ADC_Init8b_hardware(void)
{
	//Habilita el clock para el ADC0
	SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
	
	//Triggers alternativos habilitados, pre-trigger para canal B, 
	//Modulo PIT0 para trigger
	SIM_SOPT7 |= SIM_SOPT7_ADC0ALTTRGEN_MASK | SIM_SOPT7_ADC0PRETRGSEL_MASK
				| SIM_SOPT7_ADC0TRGSEL(4);
	
	ADC0_CFG1 |= (ADC_CFG1_MODE(0) | 
			      ADC_CFG1_ADIV(2));
	
	ADC0_SC1B  |= ADC_SC1_ADCH(31); //Disable module
	
	//Hardware trigger
	ADC0_SC2 |= ADC_SC2_ADTRG_MASK;
	
	ADC0_CFG2 |= ADC_CFG2_MUXSEL_MASK; //Escucha los canales b
}

void ADC_Init8b_software(void)
{
	SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
	
	ADC0_CFG1 |= (ADC_CFG1_MODE(0) | 
			      ADC_CFG1_ADIV(2));
	
	ADC0_SC1A  = ADC_SC1_ADCH(31);
}

void ADC_enable_chA (void)
{
	ADC0_SC2 &= (~ADC_SC2_ADTRG_MASK);
	ADC0_CFG2 &= (~ADC_CFG2_MUXSEL_MASK);
}

void ADC_enable_chB (void)
{
	ADC0_SC2 |= ADC_SC2_ADTRG_MASK;
	ADC0_CFG2 |= ADC_CFG2_MUXSEL_MASK;
}

unsigned short ADC_read_software(unsigned char channelNumber) 
{
	ADC0_SC1A = channelNumber & ADC_SC1_ADCH_MASK; 	//Write to SC1A to start conversion
	while(ADC0_SC2 & ADC_SC2_ADACT_MASK);  			//Conversion in progress
	while(!(ADC0_SC1A & ADC_SC1_COCO_MASK));			//Until conversion complete
	return ADC0_RA;
}

unsigned short ADC_read_hardware(unsigned char channelNumber) 
{
	//ADC0_SC1B  = ADC_SC1_ADCH(6); //Usa el canal6
	ADC0_SC1B  = ADC_SC1_ADCH(channelNumber); //Usa el canal en channelNumber
	return ADC0_RB;
}
