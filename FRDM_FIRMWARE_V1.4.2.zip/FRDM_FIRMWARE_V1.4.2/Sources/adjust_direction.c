/**
 *	@file	adjust_direction.c
 *	@brief	Ajusta la direcci�n central, la m�xima izquierda
 *			y la m�xima derecha en tiempo de ejecuci�n,
 *			mediante un valor de ADC se van cambiando los valores,
 *			y con la UART se elige a cual se cambiar�.
 *	@par
 *	Created on: Nov 11, 2014
 *		COPYRIGHT: (C) 2014 Luis Angel, LOS LOMO PLATEADOS.
 *		Todos los derechos reservados.
 */
 
//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "adjust_direction.h"
#include "MOTOR_DIRECTION.h"
#include "MOTOR_SPEED.h"
#include "adc.h"
#include "my_types.h"
#include "events_engine.h"
#include "events_ids.h"
#include "derivative.h" /* include peripheral declarations */

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	TYPES DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	UNIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void adjust_central_direction (void);
void adjust_left_direction (void);
void adjust_right_direction (void);


//------------------------------------------------------------------------------
//	STATE MACHINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
void init_adjust_direction (void)
{
	/*
	ADC_enable_chA();
	
	pot_ref_value = ADC_read_software(PTB2);
	
	ADC_enable_chB();
	*/
	
	//Inicializa puertos para el sw3 del TFC
	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK;
	PORTE_PCR2 = PORT_PCR_MUX(1);
	PORTE_PCR3 = PORT_PCR_MUX(1);
	//GPIOE_PDDR |= BIT2 | BIT3;
	GPIOE_PDDR &= ( (~BIT2) & (~BIT3) );
	
	//Inicializa puertos para los sw1 y sw2 del TFC
	SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
	PORTC_PCR13 = PORT_PCR_MUX(1);
	PORTC_PCR17 = PORT_PCR_MUX(1);
	//GPIOC_PDDR |= BIT17;
	GPIOC_PDDR &= ( (~BIT13) & (~BIT17) );
	
}

void adjust_direction_periodic (void)
{
	if ( (GPIOE_PDIR & BIT2) && (GPIOE_PDIR & BIT3) )
	{
		adjust_central_direction();
	}
	else if (GPIOE_PDIR & BIT2)
	{
		adjust_left_direction();
	}
	else if (GPIOE_PDIR & BIT3)
	{
		adjust_right_direction();
	}
	
	if ( GPIOC_PDIR & BIT17 )
	{
		vfn_periodic_timer_enable(CONTROL_EV);
	}
	if ( GPIOC_PDIR & BIT13 )
	{
		vfn_periodic_timer_disable(CONTROL_EV);
		set_front_direction();
		set_minimum_speed();
	}
	
}


//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS
//------------------------------------------------------------------------------
void adjust_central_direction (void)
{
	u16 pot_actual_value;
	ADC_enable_chA();
	pot_actual_value = ADC_read_software(PTB2);
	ADC_enable_chB();
	
	center_value = center_value_init + 
	(max_increment*(pot_actual_value-pot_central_value))/pot_central_value;
	
	set_front_direction();
	
}

void adjust_left_direction (void)
{
	u16 pot_actual_value;
	ADC_enable_chA();
	pot_actual_value = ADC_read_software(PTB2);
	ADC_enable_chB();
	
	max_left_value = max_left_value_init + 
	(max_increment*(pot_actual_value-pot_central_value))/pot_central_value;
	
	set_total_left();
	
}

void adjust_right_direction (void)
{
	u16 pot_actual_value;
	ADC_enable_chA();
	pot_actual_value = ADC_read_software(PTB2);
	ADC_enable_chB();
	
	max_right_value = max_right_value_init + 
	(max_increment*(pot_actual_value-pot_central_value))/pot_central_value;
	
	set_total_right();
}


//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
