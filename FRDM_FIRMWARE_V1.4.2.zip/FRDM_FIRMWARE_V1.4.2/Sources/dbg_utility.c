/**
 *	@file	dbg_utility.c
 *	@brief	Utileria que permite imprimir mensajes de debug facilmente
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "dbg_utility.h"

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
#if (DBG_MSG_ENABLE == 1)
char ca_dbg_buffer [DBG_BUFFER_SIZE] = DBG_INITIAL_STR;
u08 b_dbg_status;
#endif

#if USE_DEBUG_UTIL
char 	__no_init 		reset_function_name[64];
#endif
//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------

#if USE_DEBUG_UTIL
void vfn_check_reset_cause( void ){
	if( reset_function_name[0] ){
		DBGMSG( TEST_MSG_ENABLE, (DBG_OUT,"ERROR: Unexpected reset by watchdog. Stopped at line: %s \r\n", reset_function_name ));
	}
}
#endif
//------------------------------------------------------------------------------
