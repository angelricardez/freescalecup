/**
 *	@file	MOTOR_DIRECTION.c
 *	@brief	Controla las funciones b�sicas de los motores
 *			para dar direcci�n
 *	@par
 *		COPYRIGHT: (C) 2014 Luis Angel Torres, LOS LOMO PLATEADOS.
 *		Todos los derechos reservados.
 */
 
//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "MOTOR_DIRECTION.h"
#include "PWM.h"
#include "my_types.h"
#include "board_defs.h"
#include "dbg_uart.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	TYPES DEFINITIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	UNIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
//Si la direcci�n es positiva: gira a la derecha
//Si la direcci�n es negativa: gira a la izquierda
volatile s16 actual_direction;

volatile u16 max_right_value;
volatile u16 center_value;
volatile u16 max_left_value;

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void update_direction (void);
//------------------------------------------------------------------------------
//	STATE MACHINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
void start_motors_direction (void)
{
	max_right_value = max_right_value_init;
	center_value = center_value_init;
	max_left_value = max_left_value_init;
	//range_op_right = range_op_right_init;
	//range_op_left = range_op_left_init;
	
	enable_PWMs_direction();
	update_direction();
}

void stop_motors_direction (void)
{
	disable_PWMs_direction();
	update_direction();
}

//La direcci�n va en porcentajes
//positivos-negativos, derecha-izquierda respectivamente
void set_direction (s16 direction)
{
	if ( direction > 0 )
	{
		if ( direction < 100 )
		{
			set_duty_cycle_PWM1_direction( center_value+(((max_right_value-center_value)*direction)/100) );
		}
		else
		{
			set_duty_cycle_PWM1_direction(max_right_value);
		}
	}
	else
	{
		if ( direction > -100 )
		{
			set_duty_cycle_PWM1_direction( center_value+((center_value-max_left_value)*direction)/100 );
		}
		else
		{
			set_duty_cycle_PWM1_direction(max_left_value);
		}
		
	}
	update_direction();
}

void set_total_right (void)
{
	set_duty_cycle_PWM1_direction(max_right_value);
	update_direction();
}

void set_front_direction(void)
{
	set_duty_cycle_PWM1_direction(center_value);
	update_direction();
}

void set_total_left (void)
{
	set_duty_cycle_PWM1_direction(max_left_value);
	update_direction();
}


void increase_right_in10 (void)
{
	if ( (actual_direction + 10) < 100 )
	{
		set_direction(actual_direction + 10);
	}
	else
	{
		set_total_right();
	}
	update_direction();
}

void increase_left_in10 (void)
{
	if ( (actual_direction - 10) > -100 )
	{
		set_direction(actual_direction-10);
	}
	else
	{
		set_total_left();
	}
	update_direction();
}

s16 get_actual_direction (void)
{
	return actual_direction;
}

//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS
//------------------------------------------------------------------------------
void update_direction (void)
{
	if ( get_duty_cycle_PWM1_direction() > center_value )
	{
		//actual_direction = ( ( (get_duty_cycle_PWM1_direction() - center_value) * 100 ) / (range_op_right) );
		actual_direction = ( ( (get_duty_cycle_PWM1_direction() - 
				center_value) * 100 ) / (max_right_value-center_value) );
	}
	else
	{
		//actual_direction = ( ( (get_duty_cycle_PWM1_direction() - center_value) * 100 ) / (range_op_left) );
		actual_direction = ( ( (get_duty_cycle_PWM1_direction() - 
				center_value) * 100 ) / (center_value-max_left_value) );
	}
}

//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------


