/*
 * leds_driver.c
 *
 *  Created on: Oct 13, 2014
 *      Author: LuisAngel
 */

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "leds_driver.h"
#include "derivative.h" /* include peripheral declarations */
#include "my_types.h"
#include "dbg_utility.h"

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------
typedef struct
{
		volatile u32 * const port;
		volatile u32 * const dir;
		u32 pin;
}s_led_t;

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------
///NOTA: Esta estructura se debe modificar al agregar o quitar LEDs
const s_led_t gsa_leds [MAX_LEDS] =
{
	{	.port = &GPIOB_PTOR,
		.dir = &GPIOB_PDDR,
		.pin = BIT18,
	},
	{	.port = &GPIOB_PTOR,
		.dir = &GPIOB_PDDR,
		.pin = BIT19,
	},
	{	.port = &GPIOD_PTOR,
		.dir = &GPIOD_PDDR,
		.pin = BIT1,
	},
};

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
u08 gb_leds_state = 0;

//------------------------------------------------------------------------------
//	STATE MACHINES
//------------------------------------------------------------------------------
//Declaracion de la maquina de estados
static s_sm_t s_led_blink_sm[MAX_LEDS];
//Variables necesarias por la maquina de estados
static u32 gdw_blink_count[MAX_LEDS];
static u08 gb_blink_delay_backup[MAX_LEDS];
static u08 gb_blink_delay[MAX_LEDS];
//enumeracion de estados
enum
{
	LED_BLINK_IDLE_S = 0,
	LED_BLINK_ON_S,
	LED_BLINK_OFF_S,
	LED_BLINK_DELAY_S,
	LED_BLINK_MAX_STATES
};
//Prototipos de funciones de estado
static void vfn_led_blink_idle_s (e_leds_t);
static void vfn_led_blink_on_s (e_leds_t);
static void vfn_led_blink_off_s (e_leds_t);
static void vfn_led_blink_delay_s (e_leds_t);
//Arreglo de funciones de estado
static void (* const kavfnp_led_blink_se [LED_BLINK_MAX_STATES]) (e_leds_t) =
{
	vfn_led_blink_idle_s,
	vfn_led_blink_on_s,
	vfn_led_blink_off_s,
	vfn_led_blink_delay_s,
};
//Funcion de ejecucion de siguiente estado
/*!
 @brief	Ejecucion de siguiente estado
 */
void vfn_led_blink_sm_ens (void)
{
	u08 i;
	u08 b_flag_busy = 0;
	for (i = 0; i < MAX_LEDS; i++)
	{
		//Para cada LED
		//Ejecuta su siguiente estado
		kavfnp_led_blink_se [s_led_blink_sm[i].b_next_state] ( (e_leds_t) i);
	}
	for (i = 0; i < MAX_LEDS; i++)
	{
		//Para cada LED
		if (s_led_blink_sm[i].b_actual_state)
		{
			//En caso de que no est� en idle
			//Indicar que por lo menos una maquina de estados no est� en idle
			b_flag_busy = 1;
		}
	}
	if (!b_flag_busy)
	{
		//En caso de que todas las maquinas de estados estuviesen en idle
		//Deshabilitar el timer periodico del blink de LEDs
		vfn_periodic_timer_disable (LED_BLINK_PEV);
		DBGMSG( LEDS_MSG_EN, (DBG_OUT,"LED PEV DESHAB\r\n"));
	}
}
//Funciones de estado
/*!
 @brief	Estado idle
 */
static void vfn_led_blink_idle_s (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = LED_BLINK_IDLE_S;
}
/*!
 @brief	Enciende LED si todavia lo indica el contador
 */
static void vfn_led_blink_on_s (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = LED_BLINK_ON_S;
	if (gdw_blink_count[e_led]--)
	{
#if LEDS_TURN_ON_WITH_ONE
	*gsa_leds[e_led].port |= gsa_leds[e_led].pin;
#else
	*gsa_leds[e_led].port &= ~gsa_leds[e_led].pin;
#endif
		s_led_blink_sm[e_led].b_prev_state = LED_BLINK_ON_S;
		s_led_blink_sm[e_led].b_next_state = LED_BLINK_DELAY_S;
	}
	else
	{
		//vfn_periodic_timer_disable (LED_BLINK_PEV);
		s_led_blink_sm[e_led].b_next_state = LED_BLINK_IDLE_S;
	}
}
/*!
 @brief	Apaga LED y termina si lo indica el contador
 */
static void vfn_led_blink_off_s (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = LED_BLINK_OFF_S;

#if LEDS_TURN_ON_WITH_ONE
	*gsa_leds[e_led].port &= ~gsa_leds[e_led].pin;
#else
	*gsa_leds[e_led].port |= gsa_leds[e_led].pin;
#endif
	if (gdw_blink_count[e_led])
	{
		s_led_blink_sm[e_led].b_prev_state = LED_BLINK_OFF_S;
		s_led_blink_sm[e_led].b_next_state = LED_BLINK_DELAY_S;
	}
	else
	{
		s_led_blink_sm[e_led].b_next_state = LED_BLINK_IDLE_S;
	}
}
/*!
 @brief	Espera un tiempo para despues proceder a hacer toggle del LED
 */
static void vfn_led_blink_delay_s (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = LED_BLINK_DELAY_S;

	if ( !(--gb_blink_delay[e_led]))
	{
		gb_blink_delay[e_led] = gb_blink_delay_backup[e_led];
		if (s_led_blink_sm[e_led].b_prev_state == LED_BLINK_ON_S)
		{
			s_led_blink_sm[e_led].b_next_state = LED_BLINK_OFF_S;
		}
		else if (s_led_blink_sm[e_led].b_prev_state == LED_BLINK_OFF_S)
		{
			s_led_blink_sm[e_led].b_next_state = LED_BLINK_ON_S;
		}
	}
}

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
/*!
 @brief	Inicializa el driver de los LEDs de la tarjeta
 */
void vfn_leds_init (void)
{
	u08 i;
	for (i = 0; i < MAX_LEDS; i++)
	{
		//Salida digital
		*gsa_leds[i].dir |= gsa_leds[i].pin;
		vfn_turn_led_off ( (e_leds_t) i );
		s_led_blink_sm[i].b_actual_state = 0;
		s_led_blink_sm[i].b_next_state = 0;
		s_led_blink_sm[i].b_prev_state = 0;
		s_led_blink_sm[i].b_error_state = 0;
	}
}

/*!
 @brief	Enciende un LED
 @param[in] e_led: LED a encender
 */
void vfn_turn_led_on (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = 0;
	s_led_blink_sm[e_led].b_next_state = 0;
	s_led_blink_sm[e_led].b_prev_state = 0;
	gb_leds_state |= (1 << e_led);
#if LEDS_TURN_ON_WITH_ONE
	*gsa_leds[e_led].port |= gsa_leds[e_led].pin;
#else
	*gsa_leds[e_led].port &= ~gsa_leds[e_led].pin;
#endif
}

/*!
 @brief	Apaga un LED
 @param[in] e_led: LED a apagar
 */
void vfn_turn_led_off (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = 0;
	s_led_blink_sm[e_led].b_next_state = 0;
	s_led_blink_sm[e_led].b_prev_state = 0;
	gb_leds_state &= ~(1 << e_led);
#if LEDS_TURN_ON_WITH_ONE
	*gsa_leds[e_led].port &= ~gsa_leds[e_led].pin;
#else
	*gsa_leds[e_led].port |= gsa_leds[e_led].pin;
#endif
}

/*!
 @brief	Toglea un LED
 @param[in] e_led: LED a Toglear
 */
void vfn_led_toggle (e_leds_t e_led)
{
	s_led_blink_sm[e_led].b_actual_state = 0;
	s_led_blink_sm[e_led].b_next_state = 0;
	s_led_blink_sm[e_led].b_prev_state = 0;
	gb_leds_state ^= (1 << e_led);
	*gsa_leds[e_led].port ^= gsa_leds[e_led].pin;
}

/*!
 @brief	Regresa un LED a su estado previo
 @param[in] e_led: LED en cuesti�n
 */
void vfn_led_restore (e_leds_t e_led)
{
	if (gb_leds_state & BIT_CHECK(e_led))
	{
		vfn_turn_led_on(e_led);
	}
	else
	{
		vfn_turn_led_off(e_led);
	}
}

/*!
 @brief	Inicializa la maquina de estados de blink de LED
 @param[in] e_led: LED a parpadear
 @param[in] b_blink_count: Cantidad de veces que LED parapadea
 @param[in] b_blink_delay: Tiempo que tarda entre cada parpadeo
 */
void vfn_led_blink (e_leds_t e_led, u32 dw_blink_count, u08 b_blink_delay)
{
	gdw_blink_count[e_led] = dw_blink_count;
	gb_blink_delay_backup[e_led] = b_blink_delay;
	gb_blink_delay[e_led] = b_blink_delay;
	vfn_periodic_timer_enable (LED_BLINK_PEV);
	kavfnp_led_blink_se [LED_BLINK_ON_S] (e_led);
}

//------------------------------------------------------------------------------
