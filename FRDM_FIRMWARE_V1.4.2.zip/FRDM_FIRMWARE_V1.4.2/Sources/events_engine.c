/**
 *	@file	events_engine.c
 *	@brief	Motor de eventos del sistema
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "events_engine.h"
#include "events_ids.h"
#include "tick_timer.h"

//------------------------------------------------------------------------------
//	CONSTANTS
//------------------------------------------------------------------------------
static const u08 gkba_bit_mask [] =
{ 1, 2, 4, 8, 16, 32, 64, 128 };

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define	EVS_BYTES_QUANTITY		(((MAX_EVS - 1) / 8) + 1)
#define	PEVS_BYTES_QUANTITY		(((MAX_PEVS - 1) / 8) + 1)

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
/*!
 @var    gba_event_flags
 @brief  Flags of enabled events
 */
u08 gba_event_flags [EVS_BYTES_QUANTITY];

/*!
 @var    gwa_periodic_tmrs_counters
 @brief  Counters of periodic timers
 */
u16 gwa_periodic_tmrs_counters [MAX_PEVS];

/*!
 @var    gba_periodic_tmrs_ready_list
 @brief  Flags of posted events timers
 */
u08 gba_periodic_tmrs_ready_list [PEVS_BYTES_QUANTITY];

/*!
 @var    gba_events_ready_list
 @brief  Flags of posted events
 */
u08 gba_events_ready_list [EVS_BYTES_QUANTITY];

//Asserts init macro
//ASSERT_INIT();

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
/*!
 @brief	Inicializa el motor de eventos
 */
void vfn_events_engine_init (void)
{
	u08 b_index;
	//Periodic Timers
	b_index = (MAX_PEVS / 8);
	do
	{
		gba_periodic_tmrs_ready_list [b_index] = 0;
	} while (b_index--);
	b_index = (MAX_EVS / 8);
	//Events
	do
	{
		gba_event_flags [b_index] = 0;
		gba_events_ready_list [b_index] = 0;
	} while (b_index--);

	vfn_tb_ev_timer_init ();
}

/*!
 @brief	Ejecuta el motor de eventos (ejecutar en loop infinito de la
 funcion main)
 */
void vfn_events_engine (void)
{
	u08 b_index;
	u08* bp_rdy;
	//Events
	s_event_t *sp_events = (s_event_t *) &gksa_events [MAX_EVS - 1];
	u08* bp_events_flags = &gba_event_flags [(MAX_EVS - 1) / 8];
	b_index = MAX_EVS - 1;
	bp_rdy = &gba_events_ready_list [(MAX_EVS - 1) / 8];
	do
	{
		//Event enabled?
		if (( *bp_rdy) & gkba_bit_mask [b_index % 8])
		{
			//Event triggered?
			if (( *bp_events_flags) & gkba_bit_mask [b_index % 8])
			{
				//Event Acknoledge
				( *bp_events_flags) &= ~gkba_bit_mask [b_index % 8];
				//Event Callback
				sp_events->vfnp_cb ();
			}
		}
		//Check next element in the array?
		if ( !(b_index % 8))
		{
			bp_rdy--;
			bp_events_flags--;
		}
		sp_events--;
	} while (b_index--);
}

/*!
 @brief	Habilita un evento periodico
 */
void vfn_periodic_timer_enable (u08 b_id)
{
	//ASSERT(MAX_PERIODIC_TIMERS > b_id,1);
	if (MAX_PEVS > b_id)
	{
		gba_periodic_tmrs_ready_list [(b_id / 8)] |= gkba_bit_mask [b_id % 8];
		gwa_periodic_tmrs_counters [b_id] =
		gksa_periodic_timers [b_id].w_reload_value;
	}
	//TB_EV_TICK_ON;
}

/*!
 @brief	Deshabilita un evento periodico
 */
void vfn_periodic_timer_disable (u08 b_id)
{
	//ASSERT(MAX_PERIODIC_TIMERS > b_id,1);
	if (MAX_PEVS > b_id)
	{
		gba_periodic_tmrs_ready_list [(b_id / 8)] &= ~gkba_bit_mask [b_id % 8];
	}

	u08 i = 0;
	u08 b_event_enable_flag = 0;
	while (i < PEVS_BYTES_QUANTITY)
	{
		if (gba_periodic_tmrs_ready_list [i])
		{
			//Si hay alg�n evento habilitado
			//indicarlo
			b_event_enable_flag = 1;
		}
		i++;
	}
	if ( !b_event_enable_flag)
	{
		//Si no hay ningun evento habilitado
		//Desactivar el timer
		//TB_EV_TICK_OFF;
	}
}

/*!
 @brief	Dispara un evento asincrono
 */
void vfn_event_post (u08 b_id)
{
	//ASSERT(MAX_EVS > b_id,1);
	if (MAX_EVS > b_id)
	{
		u08 b_event_index = (u08) (b_id / 8);
		b_id = b_id % 8;
		gba_event_flags [b_event_index] |= gkba_bit_mask [b_id];
	}
}

/*!
 @brief	Habilita un evento asincrono
 */
void vfn_event_enable (u08 b_id)
{
	//ASSERT(MAX_EVS > b_id,1);
	if (MAX_EVS > b_id)
	{
		u08 b_event_index = (u08) (b_id / 8);
		b_id %= 8;
		gba_events_ready_list [b_event_index] |= gkba_bit_mask [b_id];
		//Make sure that the event flag is clear
		gba_event_flags [b_event_index] &= ~gkba_bit_mask [b_id];
	}
}

/*!
 @brief	Deshabilita un evento asincrono
 */
void vfn_event_disable (u08 b_id)
{
	//ASSERT(MAX_EVS > b_id,1);
	if (MAX_EVS > b_id)
	{
		u08 b_event_index = (u08) (b_id / 8);
		b_id %= 8;
		gba_events_ready_list [b_event_index] &= ~gkba_bit_mask [b_id];
		//Make sure that the event flag is clear
		gba_event_flags [b_event_index] &= ~gkba_bit_mask [b_id];
	}
}

/*!
 @brief	Ejecuta el motor de eventos periodicos
 */
void vfn_time_based_events_engine (void)
{
	u08 b_index;
	u16 *wp_tmr_ctr;
	u08* bp_tmr_rdy;
	s_periodic_timers_t *sp_periodic_tmr =
			(s_periodic_timers_t *) &gksa_periodic_timers [MAX_PEVS - 1];
	wp_tmr_ctr = &gwa_periodic_tmrs_counters [MAX_PEVS - 1];
	b_index = MAX_PEVS - 1;
	bp_tmr_rdy = &gba_periodic_tmrs_ready_list [(MAX_PEVS - 1) / 8];
	do
	{
		//Timer active?
		if (( *bp_tmr_rdy) & gkba_bit_mask [b_index % 8])
		{
			//Timer elapsed?
			*wp_tmr_ctr = (u16) ( *wp_tmr_ctr - 1);
			if ( !( *wp_tmr_ctr))
			{
				*wp_tmr_ctr = sp_periodic_tmr->w_reload_value;
				sp_periodic_tmr->vfnp_cb ();
			}
		}
		wp_tmr_ctr--;
		sp_periodic_tmr--;
		if ( !(b_index % 8))
		{
			bp_tmr_rdy--;
		}
	} while (b_index--);
}

//------------------------------------------------------------------------------
