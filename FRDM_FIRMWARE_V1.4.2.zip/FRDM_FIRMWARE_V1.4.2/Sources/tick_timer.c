/**
 *	@file	tick_timer.c
 *	@brief	Driver del timer que genera los Ticks para el motor de eventos
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "tick_timer.h"
#include "derivative.h"
#include "events_engine.h"
#include "events_ids.h"
#include "board_defs.h"
#include "adc.h"
#include "derivative.h" /* include peripheral declarations */

#include "dbg_uart.h"


//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
//Definiciones para los eventos basados en tiempo
#define TIMER_IN_FREC			24000	//KHz

#define TIMER0_COUNTER			((TIMER_IN_FREC*EVENT_PERIOD)/1000)
#define TIMER1_COUNTER			((TIMER_IN_FREC*PIXEL_PERIOD)/2000)

//#define quantification		((max_word_value*sensitivity_init)/100)

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
static u16 quantification;					

u32 gw_delay = 0;
//u32 gdw_tick_counts = 0;
u32 gdw_tick_counts0 = 0;
u32 gdw_tick_counts1 = 0;

u16 frame_position = 0;


//------------------------------------------------------------------------------
//	No terminadas
//------------------------------------------------------------------------------
void habilita_counter1 (void){
	PIT_TCTRL1 |= PIT_TCTRL_TEN_MASK;
}
void deshabilita_counter1 (void){
	PIT_TCTRL1 |= ~PIT_TCTRL_TEN_MASK;
}

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
/*!
 @brief	Inicializa un timer para que de el tick del evento
 basado en tiempo para que funcionen los eventos peri�dicos
 */
void vfn_tb_ev_timer_init (void)
{
	//Habilita el modulo PIT
	SYST_CLOCK_CONF_6 |= SIM_SCGC6_PIT_MASK;

	//Se pone divici�n de 0 al clock
	//SYST_CLOCK_GATE_DIV = CERO;

	/**************************
	 ***Inicializa modulo PIT**
	 **************************/
	PIT_MCR = CERO;
	//Se carga la cuenta para la interrupcion
	PIT_LDVAL0 = TIMER0_COUNTER;
	//Interrupcion y habilita cuenta
	PIT_TCTRL0 |= PIT_TCTRL_TIE_MASK | PIT_TCTRL_TEN_MASK;
	//Limpia la bandera de interrupci�n
	PIT_TFLG0 |= PIT_TFLG_TIF_MASK;
	/************************** 
	 **Finaliza inicializaci�n* 
	 **************************/
}

void camera_clk_si_init (void)
{
	//Habilita el modulo PIT
	SYST_CLOCK_CONF_6 |= SIM_SCGC6_PIT_MASK;
	/**************************
	 ***Inicializa modulo PIT**
	 **************************/
	//PIT_MCR = CERO;
	//Se carga la cuenta para la interrupcion
	PIT_LDVAL1 = TIMER1_COUNTER;
	//Interrupcion y habilita cuenta
	PIT_TCTRL1 |= PIT_TCTRL_TIE_MASK | PIT_TCTRL_TEN_MASK;
	//Limpia la bandera de interrupci�n
	PIT_TFLG1 |= PIT_TFLG_TIF_MASK;
	/************************** 
	 **Finaliza inicializaci�n* 
	 **************************/

	/****************************************
	 *      Puertos para la camara          *
	 ****************************************/
	//Habilita los puertos D y E
	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK | SIM_SCGC5_PORTD_MASK;
	
	PORTD_PCR5 |= PORT_PCR_MUX(0);	//ADC	ADC
	PORTD_PCR7 |= PORT_PCR_MUX(1);	//SI	GPIO
	PORTE_PCR1 |= PORT_PCR_MUX(1);	//CLK	GPIO
	
	//Habilita como salidas los pines PTD7 y PTE1
	GPIOD_PDDR |= BIT7;
	GPIOE_PDDR |= BIT1;
	
	/*******************************************/
	
	/*******************************************
	 * Puertos de Prueba Camara *
	 *******************************************/
	/*
	//Habilita los puertos B
	SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK;
	
	PORTE_PCR21 |= PORT_PCR_MUX(0);	//ADC	ADC
	PORTB_PCR0 |= PORT_PCR_MUX(1);	//CLK	GPIO
	PORTB_PCR1 |= PORT_PCR_MUX(1);	//SI	GPIO
	
	//Habilita como salidas los pines PTB0 y PTB1
	GPIOB_PDDR |= BIT0 | BIT1;
	*/
	
	quantification = ((max_word_value*sensitivity_init)/100);
	
}

/*!
 @brief	Genera un delay por software
 @param[in] w_time:
 */
void vfn_delay (u32 w_time)
{
	gw_delay = w_time;
	while (gw_delay);
}
//------------------------------------------------------------------------------
//	INTERRUPT SERVICE ROUTINES
//------------------------------------------------------------------------------
/*!
 @brief	Rutina de interrupcion del timer usado para ticks del motor de
 eventos periodicos
 */
extern void PIT_IRQHandler()
{
	
	//Interrupcion por PIT0
	if(PIT_TFLG0 & PIT_TFLG_TIF_MASK)
	{
		PIT_TFLG0 |= PIT_TFLG_TIF_MASK;
		
		FAST_EVENT_SET(TB_EV);
		
		if ( gw_delay )
		{
			gw_delay--;
		}
		gdw_tick_counts0++;
	}
	
	
	//Interrupcion por PIT1
	if (PIT_TFLG1 & PIT_TFLG_TIF_MASK)
	{
		PIT_TFLG1 |= PIT_TFLG_TIF_MASK;

		if (!(gdw_tick_counts1 % 2))
		{
			
			if( ADC_read_hardware(PTD5) > quantification )
			{
				//vfn_dbg_uart_tx ("0", 1);
				//new_frame[frame_position] = 0;
				actual_frame[frame_position] = 0;
				//DBGMSG ( APP_MSG_EN , (DBG_OUT,"0") );
			}
			else
			{
				//vfn_dbg_uart_tx ("1", 1);
				//new_frame[frame_position] = 1;
				actual_frame[frame_position] = 1;
				//DBGMSG ( APP_MSG_EN , (DBG_OUT,"1") );
			}
			//new_frame[frame_position] = ADC_read_hardware(PTD5);
			//actual_frame[frame_position] = ADC_read16b(4);
			frame_position++;
		}

		gdw_tick_counts1++;
		GPIOD_PCOR = BIT7;
		//GPIOB_PCOR = BIT1;
		
		//vfn_dbg_uart_dato_tx(frame_position);

		if ( (gdw_tick_counts1 > 257) && (~(GPIOE_PDOR | ~BIT1)) )
			//if ( (gdw_tick_counts > 257) && (~(GPIOB_PDOR | ~BIT0)) )
		{
			//*actual_frame = *new_frame;
			GPIOD_PTOR = BIT7;
			//GPIOB_PTOR = BIT1;
			
			/*
			if ( frame_position > 127 )
			{
				vfn_dbg_uart_tx ("\r\n128\r\n", 10);
			}
			*/
			
			gdw_tick_counts1 = 0;
			frame_position = 0;

		}
		GPIOE_PTOR = BIT1;
		//GPIOB_PTOR = BIT0;

	}
}

//------------------------------------------------------------------------------
