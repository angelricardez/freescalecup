/*
 * main implementation: use this 'C' sample to create your own application
 *
 */

#include "derivative.h" /* include peripheral declarations */
#include "my_types.h"
#include "board_defs.h"
#include "tick_timer.h"
#include "events_engine.h"
#include "events_ids.h"
#include "leds.h"
#include "PWM.h"
#include "CrystalClock.h"
#include "MOTOR_SPEED.h"
#include "MOTOR_DIRECTION.h"
#include "dbg_defs.h"
#include "dbg_utility.h"
#include "dbg_uart.h"
#include "camara.h"
#include "control.h"
#include "adjust_direction.h"



//------------------------------------------------------------------------------
//	PRIVATE FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void vfn_time_based_events_engine (void);
void vfn_dbg_uart_rx_cb (void);
void ADC_Init16b_hardware(void);
void ADC_Init16b_software(void);
void speed_lecture_event(void);


s32 porcentaje = 0;
//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------
const s_periodic_timers_t gksa_periodic_timers [MAX_PEVS] =
{
	//{ TIMEOUTS_CB, TIMEOUTS_RELOAD },
	{ LED_SM_PERIODIC, TIME_LEDS },
	{LED_PERIODIC, FREC_LED_PERIODIC},			//LED periodico
	{UPTADE_FRAME_FUNC, UPDATE_FRAME_FREC},		//Actualiza el frame
	{CONTROL_NEXT_FUNC,CONTROL_MAQUINA_FREC},	//Funciones de control
	{SEND_PIXEL_FUNC,SEND_PIXEL_FREC},			//Envia un pixel por la UART
	{DIR_ADJ_FUNC,DIR_ADJ_FREC}					//Ajusta por un pot la dir
};
const s_event_t gksa_events [MAX_EVS] =
{
	vfn_time_based_events_engine,
	vfn_dbg_uart_rx_cb,
	/*vfn_rtc_alarm_cb,
	vfn_rtc_noon_cb,
	vfn_at_uart_rx_frame_cb,
	vfn_at_uart_rx_cb,
	vfn_i2c_tx_rx_finish_cb,
	vfn_sim5320_dummy_cb,
	vfn_mma_interrupt_1_cb,
	vfn_mma_movement_2_cb,
	vfn_mma_fall_cb,
	vfn_mma_crash_cb,*/
};

int main(void)
{
	//Habilita Interrupciones desde el core ARM
	
	NVIC_ISER = BIT22 | BIT12;
	NVIC_ICPR = BIT22 | BIT12;
	
	//NVIC_ISER = 0x00F01000u;
	//NVIC_ICPR = 0x00F01000u;
	
	//Checar bits de control del H Bridge

	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK;
	PORTE_PCR1 = PORT_PCR_MUX(1);
	PORTE_PCR21 = PORT_PCR_MUX(1);
	PORTE_PCR20 = PORT_PCR_MUX(1);
	GPIOE_PDDR = BIT21 | BIT1;
	GPIOE_PDOR = BIT21;
	GPIOE_PCOR = BIT20;

	
	
	//Inicia el clock
	InitClock();
	//Inicialiaza el contador
	vfn_tb_ev_timer_init();
	//Inicializa el generador de eventos
	vfn_events_engine_init();
	//Inicializa los puertos de leds
	vfn_led_init();
	//Inicializa el PWM
	init_PWM();
	//Inicializa el UART-DBG
	vfn_dbg_uart_init ();
	//Inicializa el ADC0
	ADC_Init16b_hardware();
	//ADC_Init16b_software();
	//Inicializa el clk, SI y ADC de la c�mara
	camera_clk_si_init();
	
	//Inicializa el ajuste manual de la direcci�n
	init_adjust_direction();
	
	
	
	
	start_motors_speed();
	start_motors_direction();
	set_front_direction();
	set_minimum_speed();
	
	//Enciende la maquina de estados del control
	start_control_machine();


	
	//Eventos Asincronos
	vfn_event_enable(TB_EV);
	vfn_event_enable (UART_DBG_RX_EV);
	
	//Eventos periodicos
	vfn_periodic_timer_enable(LED_BLINK_PEV);
	vfn_periodic_timer_enable(SEND_PIXEL_EV);
	vfn_periodic_timer_enable(DIR_ADJ_EV);
	//vfn_periodic_timer_enable(UPDATE_FRAME_EV);
	//vfn_periodic_timer_enable(CONTROL_EV);
	
	vfn_dbg_uart_tx("\r\n�LOMO PLATEADO ENCENDIDO!\r\n",32);
	
	for(;;) {	
		vfn_events_engine();
	}
	return 0;
}

void vfn_dbg_uart_rx_cb (void)
{
	switch (gb_uart_dbg_rx_data)
	{
		case 'w':
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: increase speed\r\n") );
			increase_speed_in10 ();
		break;
		case 's':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: decrease speed\r\n" ) );
			decrease_speed_in10 ();
		break;																	
		case 'a':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: increase left\r\n") );
			set_total_left();
			//increase_left_in10 ();
		break;																	
		case 'd':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: increase right\r\n") );
			//increase_right_in10 ();
			set_total_right();
		break;																	
		case 'z':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: apagar motor\r\n") );
			set_minimum_speed();
			vfn_periodic_timer_enable(CONTROL_EV);
			vfn_periodic_timer_enable(SEND_PIXEL_EV);
		break;																	
		case 'x':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: Apaga todo\r\n") );
			set_front_direction();
			set_minimum_speed();
			vfn_periodic_timer_disable(CONTROL_EV);
			vfn_periodic_timer_disable(SEND_PIXEL_EV);
		break;
		
		
		case 'e':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: total right\r\n") );
			weel_turn_right(100);
		break;																	
		case 'q':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: total left\r\n") );
			weel_turn_left(100);
		break;
		
		
		case 'g':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: mas direccion\r\n") );
			porcentaje += 10;
			set_direction(get_actual_direction()+10);
		break;		
		case 'f':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: menos direccion\r\n") );
			set_direction(get_actual_direction()-10);
			porcentaje -= 10;
		break;		
		case 'v':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: start motors DC\r\n") );
			start_motors_speed();
		break;
		case 'c':																
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: stop motors DC\r\n") );
			set_minimum_speed();
			stop_motor_speed();
		break;
		
		default:
			DBGMSG ( APP_MSG_EN , (DBG_OUT,"DBG UART rx: INVALID\r\n") );
		break;
	}
}




