/**
 *	@file	dbg_uart.c
 *	@brief	Driver de UART usada para debug
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "dbg_uart.h"
#include "board_defs.h"
#include "derivative.h" /* include peripheral declarations */
#include "events_engine.h"
#include "events_ids.h"
#include "dbg_defs.h"
#include "dbg_utility.h"


//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------

#define DBG_UART_CLK_FREQUENCY  (SMCLK_FREQ)
#define DBG_UART_BAUD_RATE      (9600)
#define DBG_UART_DIVIDER		((double)DBG_UART_CLK_FREQUENCY/(double)DBG_UART_BAUD_RATE)
#define DBG_UART_BRWx     		((unsigned int)DBG_UART_DIVIDER)
#define DBG_UART_BRSx     		(unsigned char)( ((double)DBG_UART_DIVIDER - (double)DBG_UART_BRWx)*(double)8.0  )

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------
#define DBG_UART_EN_TX_INT		( DBG_UART_IE |=  UCTXIE )
#define DBG_UART_DIS_TX_INT  	( DBG_UART_IE &=~ UCTXIE )
#define DBG_UART_EN_RX_INT   	( DBG_UART_IE |=  UCRXIE )
#define DBG_UART_DIS_RX_INT  	( DBG_UART_IE &=~ UCRXIE )
#define DBG_UART_CLR_TX_FLAG  	( DBG_UART_IFG &= ~UCTXIFG )
#define	DBG_UART_TX_BUSY		( !(DBG_UART_IFG & UCTXIFG) )

#define sysclk				24000	//KHz
#define baud				9600	//Baud Rate

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
volatile u08 gb_uart_dbg_rx_data;

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS
//------------------------------------------------------------------------------
/*!
 @brief	Inicializa el driver de la UART de debug de la tarjeta
 */
/*
void vfn_dbg_uart_init (void)
{
	volatile unsigned int scope;
	//Funcion de periferico en los pines
	DBG_UART_TX_SEL |= DBG_UART_TX_PIN;
	DBG_UART_RX_SEL |= DBG_UART_RX_PIN;
	//Resetea m�quina de estados de la USCI
	DBG_UART_CTL1 |= UCSWRST;
	//Deshabilita paridad, LSB primero, 8 bits, 1 stop bit, modo UART, Async
	DBG_UART_CTL0 = 0x00;
	//Selecciona SMCLK y mantiene el reset
	DBG_UART_CTL1 |= UCSSEL_2;
	//Configura baud rate
	DBG_UART_BR0 = (u08) (DBG_UART_BRWx & 0x00FF);
	DBG_UART_BR1 = (u08) ((DBG_UART_BRWx & 0xFF00) >> 8);
	//Ajuste fino de baud rate
	DBG_UART_MCTL |= (DBG_UART_BRSx << 1);
	DBG_UART_CTL1 &= ~UCSWRST;
	//Habilita solamente interrupci�n de recepci�n
	//TODO @LC: Comentado para debug ya que llegan datos a lo bruto
	DBG_UART_EN_RX_INT;
	//Deshabilita interrupcion TX
	DBG_UART_DIS_TX_INT;
	//Habilita evento de recepcion de datos
	vfn_event_enable (UART_DBG_RX_EV);
}
 */

void vfn_dbg_uart_init(void)
{
	u08 i;
	u32 calculated_baud = 0;
	u32 baud_diff = 0;
	u32 osr_val = 0;
	u32 sbr_val, uart0clk;
	u32 baud_rate;
	u32 reg_temp = 0;
	u32 temp = 0;

	//Prescaler de 2 al clock del BUS
	SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK;
	//Selecciona el clock MCGFLLCLK
	SIM_SOPT2 |= SIM_SOPT2_UART0SRC(1);

	SIM_SCGC4 |= SIM_SCGC4_UART0_MASK;

	// Disable UART0 before changing registers
	UART0_C2 &= ~(UART0_C2_TE_MASK | UART0_C2_RE_MASK);

	/*
    // Verify that a valid value has been passed to TERM_PORT_NUM and update
    // uart0_clk_hz accordingly.  Write 0 to TERM_PORT_NUM if an invalid 
    // value has been passed.  
    if (TERM_PORT_NUM != 0)
    {
        reg_temp = SIM_SOPT2;
        reg_temp &= ~SIM_SOPT2_UART0SRC_MASK;
        reg_temp |= SIM_SOPT2_UART0SRC(0);
        SIM_SOPT2 = reg_temp;

			  // Enter inifinite loop because the 
			  // the desired terminal port number 
			  // invalid!!
			  while(1)
				{}
    }
	 */


	// Initialize baud rate
	baud_rate = baud;

	// Change units to Hz
	uart0clk = sysclk * 1000;
	// Calculate the first baud rate using the lowest OSR value possible.  
	i = 4;
	sbr_val = (u32)(uart0clk/(baud_rate * i));
	calculated_baud = (uart0clk / (i * sbr_val));

	if (calculated_baud > baud_rate)
		baud_diff = calculated_baud - baud_rate;
	else
		baud_diff = baud_rate - calculated_baud;

	osr_val = i;

	// Select the best OSR value
	for (i = 5; i <= 32; i++)
	{
		sbr_val = (u32)(uart0clk/(baud_rate * i));
		calculated_baud = (uart0clk / (i * sbr_val));

		if (calculated_baud > baud_rate)
			temp = calculated_baud - baud_rate;
		else
			temp = baud_rate - calculated_baud;

		if (temp <= baud_diff)
		{
			baud_diff = temp;
			osr_val = i; 
		}
	}
	//UART0_C3 |= UART0_C3_TXINV_MASK;
	//UART0_C1 |= UART0_C1_ILT_MASK;

	if (baud_diff < ((baud_rate / 100) * 3))
	{
		// If the OSR is between 4x and 8x then both
		// edge sampling MUST be turned on.  
		if ((osr_val >3) && (osr_val < 9))
			UART0_C5|= UART0_C5_BOTHEDGE_MASK;

		// Setup OSR value 
		reg_temp = UART0_C4;
		reg_temp &= ~UART0_C4_OSR_MASK;
		reg_temp |= UART0_C4_OSR(osr_val-1);

		// Write reg_temp to C4 register
		UART0_C4 = reg_temp;

		reg_temp = (reg_temp & UART0_C4_OSR_MASK) + 1;
		sbr_val = (u32)((uart0clk)/(baud_rate * (reg_temp)));

		/* Save off the current value of the uartx_BDH except for the SBR field */
		reg_temp = UART0_BDH & ~(UART0_BDH_SBR(0x1F));

		UART0_BDH = reg_temp |  UART0_BDH_SBR(((sbr_val & 0x1F00) >> 8));
		UART0_BDL = (u08)(sbr_val & UART0_BDL_SBR_MASK);

		/* Enable receiver and transmitter */
		UART0_C2 |= (UART0_C2_TE_MASK | UART0_C2_RE_MASK | UART0_C2_RIE_MASK );
	}
	else
	{
		// Unacceptable baud rate difference
		// More than 3% difference!!
		// Enter infinite loop!
		while(1)
		{}
	}	
	//Configura los puertos PTD6-Rx y PTA2-Tx
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTD_MASK;
	PORTD_PCR6 |= PORT_PCR_MUX(3);
	PORTA_PCR2 |= PORT_PCR_MUX(2);

}

/*!
 @brief	Transmite datos por la uart de debug esperando a que la transmision
 se complete
 @param[in] bp_tx_buf: apuntador al buffer a transmitir
 @param[in] w_tx_count: cantidad de datos a transmitir
 */
/*
void vfn_dbg_uart_tx (char * bp_tx_buf, u16 w_tx_count)
{
	//ASSERT(wTxCount && (bpTxBuf != NULL),1);
	if (w_tx_count)
	{
		while (DBG_UART_TX_BUSY);
		do
		{
			DBG_UART_TXBUF = *bp_tx_buf++;
			while (DBG_UART_TX_BUSY);
		} while (--w_tx_count);
	}
}
 */

void vfn_dbg_uart_tx (char * bp_tx_buf, u16 w_tx_count)
{
	//ASSERT(wTxCount && (bpTxBuf != NULL),1);
	if (w_tx_count)
	{
		while ( !(UART0_S1 & UART0_S1_TDRE_MASK) );
		do
		{
			UART_D_REG(UART0_BASE_PTR) = *bp_tx_buf++;
			while ( !(UART0_S1 & UART0_S1_TDRE_MASK) );
		} while (--w_tx_count);
	}
}

void vfn_dbg_uart_dato_tx (char bp_tx_buf)
{

	while ( !(UART0_S1 & UART0_S1_TDRE_MASK) );

	UART_D_REG(UART0_BASE_PTR) = bp_tx_buf;
	
	while ( !(UART0_S1 & UART0_S1_TDRE_MASK) );

}



/*!
 @brief	Rutina de interrupcion de la UART de debug
 */
/*
#pragma vector = DBG_UART_INTERRUPT_VECTOR
__interrupt void vfn_dbg_uart_isr (void)
{
	switch (__even_in_range (DBG_UART_IV, 4))
	{
		case 0:                 // Vector 0 - no interrupt
		break;
		case 2:					// Vector 2 - RXIFG
			gb_uart_dbg_rx_data = DBG_UART_RXBUF;
			vfn_event_post (UART_DBG_RX_EV);
		break;
		case 4:                 // Vector 4 - TXIFG
		break;
		default:
		break;
	}
}
 */

extern void UART0_IRQHandler()
{
	gb_uart_dbg_rx_data = UART_D_REG(UART0_BASE_PTR);
	vfn_event_post (UART_DBG_RX_EV);
}

//------------------------------------------------------------------------------
