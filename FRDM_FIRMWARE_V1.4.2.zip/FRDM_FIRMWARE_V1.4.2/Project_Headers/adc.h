/*
 * adc.h
 *
 *  Created on: Oct 23, 2014
 *      Author: LuisAngel
 */

#ifndef ADC_H_
#define ADC_H_

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "derivative.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define trigger						PITtrigger1

#define	ExternalTrigger  			0
#define	CPM0output					1
#define	PITtrigger0					4
#define	PITtrigger1					5
#define	TPM0overflow				8
#define	TPM1overflow				9
#define	TPM2overflow				10
#define	RTCalarm					12
#define	RTCseconds					13
#define	LPTMR0trigger				14

#define PTB2						12
#define PTB3						13

#define PTC0						14
#define PTC1						15
#define PTC2						11

#define PTD1						5
#define PTD5						6
#define PTD6						7

#define PTE20						0
#define PTE21						4
#define PTE22						3
#define PTE23						7

#define desactivate_adc				31


//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void ADC_Init16b_hardware(void);
void ADC_Init16b_software(void);
void ADC_Init8b_hardware(void);
void ADC_Init8b_software(void);
void ADC_enable_chA (void);
void ADC_enable_chB (void);
unsigned short ADC_read_hardware(unsigned char channelNumber);
unsigned short ADC_read_software(unsigned char channelNumber);


#endif /* ADC_H_ */
