/**
 *	@file	my_types.h
 *	@brief	Definiciones de tipo de datos del sistema
 *	@par
 *		COPYRIGHT: (C) 2014 Lomos Plateados.
 *		Todos los derechos reservados.
 */

#ifndef __MY_TYPES_H__
#define __MY_TYPES_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include <stdint.h>

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define ENTER_STRING    ("\r\n")
#define	INIT_DEFAULT_SM {0,0,0,0}

//Definici�n de BITS
#define CERO					(0x00000000)
#define BIT0					(0x00000001)
#define BIT1					(0x00000002)
#define BIT2					(0x00000004)
#define BIT3					(0x00000008)
#define BIT4					(0x00000010)
#define BIT5					(0x00000020)
#define BIT6					(0x00000040)
#define BIT7					(0x00000080)
#define BIT8					(0x00000100)
#define BIT9					(0x00000200)
#define BIT10					(0x00000400)
#define BIT11					(0x00000800)
#define BIT12					(0x00001000)
#define BIT13					(0x00002000)
#define BIT14					(0x00004000)
#define BIT15					(0x00008000)
#define BIT16					(0x00010000)
#define BIT17					(0x00020000)
#define BIT18					(0x00040000)
#define BIT19					(0x00080000)
#define BIT20					(0x00100000)
#define BIT21					(0x00200000)
#define BIT22					(0x00400000)
#define BIT23					(0x00800000)
#define BIT24					(0x01000000)
#define BIT25					(0x02000000)
#define BIT26					(0x04000000)
#define BIT27					(0x08000000)
#define BIT28					(0x10000000)
#define BIT29					(0x20000000)
#define BIT30					(0x40000000)
#define BIT31					(0x80000000)

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------
#define COUNTER(x) static u32 x = 0; \
                    x++
#define	BIT_CHECK(x)					(1 << x)
//------------------------------------------------------------------------------
//	TYPES DEFINITIONS
//------------------------------------------------------------------------------
typedef uint8_t u08;
typedef int8_t s08;
typedef uint16_t u16;
typedef int16_t s16;
typedef uint32_t u32;
typedef int32_t s32;
typedef uint64_t u64;
typedef int64_t s64;

typedef double gps_pos_t;
//------------------------------------------------------------------------------
//  ENUMERATIONS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------
typedef struct
{
		u08 b_actual_state;
		u08 b_next_state;
		u08 b_prev_state;
		u08 b_error_state;
} s_sm_t;

typedef struct
{
		u08 b_second;
		u08 b_minute;
		u08 b_hour;
} s_time_t;

typedef struct
{
		u16 w_year;
		u08 b_month;
		u08 b_day;
		u08 b_day_of_week;
} s_date_t;


//------------------------------------------------------------------------------
//	UNIONS
//------------------------------------------------------------------------------
typedef union
{
		u16 w;
		struct
		{
				u08 b_h;
				u08 b_l;
		} bytes;
} u_word_t;

typedef union
{
		u32 dw;
		struct
		{
				u16 w_h;
				u16 w_l;
		} words;
		struct
		{
				u08 b_h_h;
				u08 b_h_l;
				u08 b_l_h;
				u08 b_l_l;
		} bytes;
} u_double_word_t;

typedef union
{
		u64 dw;
		struct
		{
				u32 w_h;
				u32 w_l;
		} integer ;
		struct
		{
				u16 b_h_h;
				u16 b_h_l;
				u16 b_l_h;
				u16 b_l_l;
		} words;
		struct
		{
				u08 b_h_h_h;
				u08 b_h_h_l;
				u08 b_h_l_h;
				u08 b_h_l_l;
				u08 b_l_h_h;
				u08 b_l_h_l;
				u08 b_l_l_h;
				u08 b_l_l_l;
		} bytes;
} u_four_word_t;



#endif /*__MY_TYPES_H__*/

//------------------------------------------------------------------------------

