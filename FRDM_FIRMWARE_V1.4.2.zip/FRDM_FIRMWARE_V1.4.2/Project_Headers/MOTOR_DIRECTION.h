/*
 * MOTOR_DIRECTION.h
 *
 *  Created on: Oct 8, 2014
 *      Author: LuisAngel
 */

#ifndef MOTOR_DIRECTION_H_
#define MOTOR_DIRECTION_H_

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "my_types.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define max_right_value_init			1120//en centesimas del duty cycle
#define center_value_init				945	//en centesimas del duty cycle
#define max_left_value_init				770	//en centesimas del duty cycle

#define range_op_right_init				( max_right_value_init - center_value_init )
#define range_op_left_init				( center_value_init - max_left_value_init )

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
//volatile u16 max_right_value;
//volatile u16 center_value;
//volatile u16 max_left_value;

extern volatile u16 max_right_value;
extern volatile u16 center_value;
extern volatile u16 max_left_value;
//static u16 range_op_right;
//static u16 range_op_left;

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void start_motors_direction (void);
void stop_motors_direction (void);
void set_direction (s16 direction);
void set_total_right (void);
void set_front_direction(void);
void set_total_left (void);
void increase_right_in10 (void);
void increase_left_in10 (void);
s16 get_actual_direction (void);


#endif /* MOTOR_DIRECTION_H_ */
