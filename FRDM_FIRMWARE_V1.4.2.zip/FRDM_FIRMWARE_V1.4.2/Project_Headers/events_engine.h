/**
 *	@file	events_engine.h
 *	@brief	Motor de eventos del sistema
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

#ifndef	__EVENTS_ENGINE_H__
#define	__EVENTS_ENGINE_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "my_types.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define PERIODIC_TIMER_PERIOD	(1)

//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------
#define FAST_EVENT_SET(event_id)     (gba_event_flags[0]|=(1<<event_id))

//------------------------------------------------------------------------------
//	STRUCTURES
//------------------------------------------------------------------------------
typedef struct
{
		void (* const vfnp_cb) (void);
		u16 w_reload_value;
} s_periodic_timers_t;

typedef struct
{
		void (* const vfnp_cb) (void);
} s_event_t;

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
extern const s_periodic_timers_t gksa_periodic_timers [];
extern u08 gba_event_flags [];
extern const s_event_t gksa_events [];

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void vfn_events_engine_init (void);
void vfn_events_engine (void);
void vfn_time_based_events_engine (void);
void vfn_event_post (u08 b_id);
void vfn_event_enable (u08 b_id);
void vfn_event_disable (u08 b_id);
void vfn_periodic_timer_enable (u08 b_id);
void vfn_periodic_timer_disable (u08 b_id);

#endif /*__EVENTS_ENGINE_H__*/

//------------------------------------------------------------------------------
