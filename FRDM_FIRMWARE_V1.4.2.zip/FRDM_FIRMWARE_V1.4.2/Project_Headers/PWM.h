/**
 *	@file	PWM.h
 *	@brief	Las funciones que se usan para inicializar y controlar el PWM 
 *			se indican en este archivo
 *	@par
 *		COPYRIGHT: (C) 2014 Luis Angel, LOS LOMO PLATEADOS.
 *		Todos los derechos reservados.
 */
 
#ifndef PWM_H__
#define PWM_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "my_types.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define PWM_1_to_4_period				20	//ms
#define PWM_5_6_period					20	//ms
#define TPM0_PWMs_default_dutycycle		0 	//%
#define TPM1_PWMs_default_dutycycle		0	//%
#define PWM_direction_max_value			9	//%
#define TPM_clock_in					24	//MHz---Checar este!!!!
#define TPM0_prescaler					128	//Si se modifica,
											//tambi�n modificar el registro TPM0_SC
#define TPM1_prescaler					128	//Si se modifica,
											//tambi�n modificar el registro TPM1_SC

#define TPM0_counter_value				((PWM_1_to_4_period*TPM_clock_in*1000)/TPM0_prescaler)
#define TPM0_duty_counter_init			((TPM0_counter_value*TPM0_PWMs_default_dutycycle)/100)
#define TPM1_counter_value				((PWM_5_6_period*TPM_clock_in*1000)/TPM1_prescaler)
#define TPM1_duty_counter_init			((TPM1_counter_value*TPM1_PWMs_default_dutycycle)/100)

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void init_PWM (void);
void enable_PWMs_speed (void);
void enable_PWMs_direction (void);
void disable_PWMs_speed (void);
void disable_PWMs_direction (void);
void set_duty_cycle_PWM1 (u16 porcentaje);
void set_duty_cycle_PWM2 (u16 porcentaje);
void set_duty_cycle_PWM3 (u16 porcentaje);
void set_duty_cycle_PWM4 (u16 porcentaje);
void set_duty_cycle_PWM5 (u16 porcentaje);
void set_duty_cycle_PWM1_direction (u16 porcentaje);
u16 get_duty_cycle_PWM1 (void);
u16 get_duty_cycle_PWM2 (void);
u16 get_duty_cycle_PWM3 (void);
u16 get_duty_cycle_PWM4 (void);
u16 get_duty_cycle_PWM1_direction (void);
u16 get_duty_cycle_PWM2_direction (void);

#endif /*PWM_H__*/
//------------------------------------------------------------------------------

