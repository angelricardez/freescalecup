/*
 * leds_driver.h
 *
 *  Created on: Oct 13, 2014
 *      Author: LuisAngel
 */

#ifndef __LEDS_H__
#define __LEDS_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "board_defs.h"
#include "events_engine.h"
#include "events_ids.h"
#include "my_types.h"
//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define	LED_BLINK_TMR_RELOAD	(10/PERIODIC_TIMER_PERIOD)

#define	LED_BLINK_FAST		(10)
#define	LED_BLINK_MEDIUM	(40)
#define	LED_BLINK_SLOW		(80)
//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------
///NOTA: Esta enumeraci�n se debe modificar al agregar o quitar LEDs
typedef enum
{
	DBG1_RED_LED,
	DBG2_GREEN_LED,
	DBG3_BLUE_LED,
	MAX_LEDS
} e_leds_t;

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void vfn_leds_init (void);
void vfn_turn_led_on (e_leds_t e_led);
void vfn_turn_led_off (e_leds_t e_led);
void vfn_led_toggle (e_leds_t e_led);
void vfn_led_restore (e_leds_t e_led);
void vfn_led_blink_sm_ens (void);
void vfn_led_blink (e_leds_t e_led, u32 dw_blink_count, u08 b_blink_delay);
#endif /*__LEDS_H__*/

//------------------------------------------------------------------------------
