/**
 *	@file	tick_timer.h
 *	@brief	Driver del timer que genera los Ticks para el motor de eventos
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

#ifndef __TICK_TIMER_H__
#define __TICK_TIMER_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "my_types.h"
#include "derivative.h" 
//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define EVENT_PERIOD			1000	//us
#define PIXEL_PERIOD			550		//us

#define sensitivity_init		85 //porcentaje
#define max_word_value						65535
//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
extern u32 gdw_tick_counts;
//volatile u16 new_frame[128];
volatile u16 actual_frame[128];
//extern u16 quantification;
//------------------------------------------------------------------------------
//	PUBLIC FUNCTIONS PROTOTYPES
//------------------------------------------------------------------------------
void vfn_tb_ev_timer_init (void);
void camera_clk_si_init (void);
void vfn_delay (u32 w_time);

#endif /*__TICK_TIMER_H__*/

//------------------------------------------------------------------------------
