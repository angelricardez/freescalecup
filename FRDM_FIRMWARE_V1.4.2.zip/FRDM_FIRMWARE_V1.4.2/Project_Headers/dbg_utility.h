/**
 *	@file	dbg_utility.h
 *	@brief	Utileria que permite imprimir mensajes de debug facilmente
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

#ifndef __DBG_UTILITY_H__
#define __DBG_UTILITY_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "my_types.h"
#include "dbg_defs.h"
#include <stdio.h>
#include <string.h>
#include "dbg_uart.h"

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define DBG_INITIAL_STR   	"D: "
#define DBG_BUFFER_SIZE   	(100 + sizeof(DBG_INITIAL_STR) - 1)
#define DBG_OUT   			(&ca_dbg_buffer[sizeof(DBG_INITIAL_STR) - 1])
#define	USE_DEBUG_UTIL		(0)


//------------------------------------------------------------------------------
//	MACROS
//------------------------------------------------------------------------------
#if (DBG_MSG_ENABLE)
	#define DBG_TX (vfn_dbg_uart_tx)
	#define DBGMSG(cond,printf_exp) { if(cond) { sprintf printf_exp;		\
						DBG_TX( &ca_dbg_buffer[0], strlen(&ca_dbg_buffer[0]) ); } }
	#define	DBGMSG2(cond,string,count) { if(cond) {DBG_TX(string,count);} }
	#define DBGMSG3(cond,printf_exp) { if(cond) { sprintf printf_exp;		\
						DBG_TX( &ca_dbg_buffer[4], strlen(&ca_dbg_buffer[4]) ); } }
#else
	#define DBGMSG(cond,printf_exp)  {}
	#define	DBGMSG2(cond,string,count) {}
	#define DBGMSG3(cond,printf_exp) {}
#endif

#ifdef __CCS__
#define __no_init    __attribute__ ((section (".noinit")))
#endif

#if USE_DEBUG_UTIL
#define get_execution_location(){ \
	sprintf ( reset_function_name, "%d::%s in %s\n",\
                      __LINE__, __FILE__, __func__); }

#else
#define get_execution_location()		{}
#endif

//------------------------------------------------------------------------------
//	VARIABLES
//------------------------------------------------------------------------------
extern 	char ca_dbg_buffer [];
extern 	u08 b_dbg_status;
extern 	char  	reset_function_name[64];
extern  u16		reset_function_line;

#endif /*__DBG_UTILITY_H__*/


void vfn_check_reset_cause( void );
//------------------------------------------------------------------------------
