/**
 *	@file	board_defs.h
 *	@brief	Definiciones de pines de la tarjeta
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

#ifndef __BOARDDEFS_H__
#define __BOARDDEFS_H__

//------------------------------------------------------------------------------
//	INCLUDES
//------------------------------------------------------------------------------
#include "derivative.h" /* include peripheral declarations */

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------w------------------------------------
#define MCLK_OUTPUT_PIN         (0)
#define SMCLK_OUTPUT_PIN        (0)
#define ACLK_OUTPUT_PIN         (0)

//Clk Frequencies
#define DESIRED_FREQ		(25000000)
#define XT1_CRYSTAL_FREQ   	(32768)
#define	SMCLK_DIV_Q			(2)
#define SYS_FREQ_RATIO		((unsigned long)DESIRED_FREQ/(unsigned long)XT1_CRYSTAL_FREQ)	//762
#define SYS_FREQ        	((unsigned long)XT1_CRYSTAL_FREQ*(unsigned long)SYS_FREQ_RATIO)	//24969216
#define SYS_FREQ_KHZ    	((unsigned long)SYS_FREQ/(unsigned long)1000)			//24969
#define MCLK_FREQ          	(SYS_FREQ)												//24969216
#define SMCLK_FREQ         	((unsigned long)MCLK_FREQ/(unsigned long)SMCLK_DIV_Q)	//12484608
#define ACLK_FREQ          	(XT1_CRYSTAL_FREQ)										//32768

//Time base event timer
#define SYST_CLOCK_CONF_6 			SIM_SCGC6
#define	SYST_CLOCK_GATE_DIV			SIM_CLKDIV1
#define TIMER_INIT 					PIT_MCR
#define	TIMER_LOADER 				PIT_LDVAL0
#define TIMER_CONTROLER 			PIT_TCTRL0
#define TIMER_IRQ_FLAG				PIT_TFLG0




//Clk Pins
#define ACLK_DIR                P11DIR
#define ACLK_SEL                P11SEL
#define ACLK_BIT                BIT0
#define MCLK_DIR                P11DIR
#define MCLK_SEL                P11SEL
#define MCLK_BIT                BIT1
#define SMCLK_DIR               P11DIR
#define SMCLK_SEL               P11SEL
#define SMCLK_BIT               BIT2

#define XT1_SEL                 P7SEL
#define XT1_BITS                (BIT0 | BIT1)

//LEDs
#define LEDSB_DIR				GPIOB_PDDR
#define LEDSB_OUT				GPIOB_PDOR
#define LEDSB_TOG				GPIOB_PTOR
#define LEDSB_CLR				GPIOB_PCOR
#define LEDSB_SET				GPIOB_PSOR

#define LEDSC_DIR				GPIOC_PDDR
#define LEDSC_OUT				GPIOC_PDOR
#define LEDSC_TOG				GPIOC_PTOR
#define LEDSC_CLR				GPIOC_PCOR
#define LEDSC_SET				GPIOC_PSOR

#define LEDSD_DIR				GPIOD_PDDR
#define LEDSD_OUT				GPIOD_PDOR
#define LEDSD_TOG				GPIOD_PTOR
#define LEDSD_CLR				GPIOD_PCOR
#define LEDSD_SET				GPIOD_PSOR

//PUERTOS

#define PUERTO_B18				PORTB_PCR18
#define PUERTO_B19				PORTB_PCR19
#define PUERTO_D1				PORTD_PCR1


//ADC inputs

//DEBUG UART
#define DBG_UART_TX_SEL           	P5SEL
#define DBG_UART_TX_OUT           	P5OUT
#define DBG_UART_TX_PIN             BIT6
#define DBG_UART_RX_SEL           	P5SEL
#define DBG_UART_RX_PIN             BIT7
#define DBG_UART_CTL1               UCA1CTL1
#define DBG_UART_CTL0               UCA1CTL0
#define DBG_UART_BR0                UCA1BR0
#define DBG_UART_BR1                UCA1BR1
#define DBG_UART_MCTL               UCA1MCTL
#define DBG_UART_IE                 UCA1IE
#define DBG_UART_IV                 UCA1IV
#define DBG_UART_IFG                UCA1IFG
#define DBG_UART_TXBUF              UCA1TXBUF
#define DBG_UART_RXBUF              UCA1RXBUF
#define DBG_UART_INTERRUPT_VECTOR   USCI_A1_VECTOR

//3G - GPS Module UART
#define AT_UART_TX_SEL           	P3SEL
#define AT_UART_TX_OUT           	P3OUT
#define AT_UART_TX_PIN             	BIT4
#define AT_UART_RX_SEL           	P3SEL
#define AT_UART_RX_PIN             	BIT5
#define AT_UART_CTL1               	UCA0CTL1
#define AT_UART_CTL0               	UCA0CTL0
#define AT_UART_BR0                	UCA0BR0
#define AT_UART_BR1                	UCA0BR1
#define AT_UART_MCTL               	UCA0MCTL
#define AT_UART_IE                 	UCA0IE
#define AT_UART_IV                 	UCA0IV
#define AT_UART_IFG                	UCA0IFG
#define AT_UART_TXBUF              	UCA0TXBUF
#define AT_UART_RXBUF              	UCA0RXBUF
#define AT_UART_INTERRUPT_VECTOR   	USCI_A0_VECTOR

//I2C for accelerometer
#define I2C_SDA_SEL           	P10SEL
#define I2C_SDA_OUT           	P10OUT
#define I2C_SDA_PIN            	BIT1
#define I2C_SCL_SEL           	P10SEL
#define I2C_SCL_OUT           	P10OUT
#define I2C_SCL_PIN				BIT2
#define I2C_CTL1               	UCB3CTL1
#define I2C_CTL0               	UCB3CTL0
#define I2C_BR0                	UCB3BR0
#define I2C_BR1                	UCB3BR1
#define I2C_MCTL               	UCB3MCTL
#define I2C_IE                 	UCB3IE
#define I2C_IV                 	UCB3IV
#define I2C_IFG                	UCB3IFG
#define I2C_TXBUF              	UCB3TXBUF
#define I2C_RXBUF              	UCB3RXBUF
#define I2C_INTERRUPT_VECTOR	USCI_B3_VECTOR
#define	I2C_SLAVE_ADDR			UCB3I2CSA
//Accelerometer INT1
#define MMA_INT1_DIR    		P1DIR
#define MMA_INT1_IN     		P1IN
#define MMA_INT1_IES    		P1IES
#define MMA_INT1_IE     		P1IE
#define MMA_INT1_IFG			P1IFG
#define MMA_INT1_PIN    		BIT5
#define	MMA_INT1_IN_PORT1		(1)
//Accelerometer INT2
#define MMA_INT2_DIR    		P1DIR
#define MMA_INT2_IN     		P1IN
#define MMA_INT2_IES    		P1IES
#define MMA_INT2_IE     		P1IE
#define MMA_INT2_IFG			P1IFG
#define MMA_INT2_PIN    		BIT6
#define	MMA_INT2_IN_PORT1		(1)





#endif /*__BOARDDEFS_H__*/

//------------------------------------------------------------------------------
