/**
 *	@file	dbg_defs.h
 *	@brief	Definiciones que indican cuestiones de debug que afectan la
 *			compilacion del codigo
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

#ifndef __DBG_DEFS_H__
#define __DBG_DEFS_H__

//------------------------------------------------------------------------------
//	DEFINITIONS
//------------------------------------------------------------------------------
#define DBG_MSG_ENABLE 				(1)

#define UTILITY_MSG_ENABLE 			(0)
#define	LEDS_MSG_EN					(0)
#define	AT_UART_MSG_EN				(1)
#define	SIM5320_AT_CMDS_MSG_EN		(0)
#define	SIM5320_AT_URC_MSG_EN		(0)
#define	MMA_MSG_ENABLE				(1)
#define ARBITER_MSG_EN				(0)
#define	APP_MSG_EN					(1)

#define USE_ASSERT                  (0)
#define USE_LPM                     (1)


#endif /*__DBG_DEFS_H__*/

//------------------------------------------------------------------------------
