/**
 *	@file	events_ids.h
 *	@brief	Lista de eventos del firmware
 *	@par
 *		COPYRIGHT: (C) 2013 CDE, ITESM.
 *		Todos los derechos reservados.
 */

#ifndef	__EVENTS_IDS_H__
#define	__EVENTS_IDS_H__

//------------------------------------------------------------------------------
//	ENUMERATIONS
//------------------------------------------------------------------------------

enum
{
	//TIMEOUTS_PEV,			//Evento periodico para el manejador de timeouts
	LED_PEV,				//Nuevo
	LED_BLINK_PEV,		//NUEVO
	UPDATE_FRAME_EV,
	CONTROL_EV,
	SEND_PIXEL_EV,
	DIR_ADJ_EV,
	MAX_PEVS
};

enum
{
	TB_EV = 0,				//Motor de eventos periodicos
	UART_DBG_RX_EV,			//Recepcion de datos por la UART de debug
	/*RTC_ALARM_EV,			//Alarma del RTC
	RTC_NOON_EV,			//Interrupci�n de medio d�a
	AT_UART_RX_FRAME_EV,	//Recepci�n de frame en el m�dulo 3G - GPS
	AT_UART_RX_EV,			//Recepci�n de datos en el m�dulo 3G - GPS
	I2C_TX_RX_FINISH_EV,	//Transaccion de I2C completada
	SIM5320_DUMMY_EV,		//Evento dummy para result codes que no tengan que
							//ejecutar algo sino solo prender una bandera
							//Este evento nunca ser� habilitado
	MMA_INTERRUPT_1_EV,		//Evento que indica data ready del acelerometro
	MMA_MOVEMENT_2_EV,		//Evento que indica la detecci�n de movimiento
	MMA_FALL_EV,			//Evento que indica la detecci�n de una caida
	MMA_CRASH_EV,			//Evento que indica la detecci�n de un choque*/

	MAX_EVS
};
#endif

//------------------------------------------------------------------------------
